$(document).ready(function() {

    var $body = $('body');


    // this allows to disable the checkValiditiy performed on form submit
    // sometimes it interacts with old browsers in a wierd way
    var disableFormSubmitCheckValidity = false;
    window.kms5main_disableFormSubmitCheckValidity = function() {
        disableFormSubmitCheckValidity = true;
    };

    //mark Ios device with a class
    if (navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
        $('html').addClass('ios');
    }
    if ($('html').hasClass('no-formvalidation')) {//HTML5 Form Validation support for old browsers
        $("form").submit(function() {
            if (!disableFormSubmitCheckValidity) {
                $('.removemeplease').remove();
                $(this).checkValidity();
            }
        });
    }

    //for ie<9 support of placeholders
    if (typeof $().placeholder != 'undefined') {
        $('input[placeholder]').placeholder();
    }
    $('#showsearch').click(function(e) {
        e.preventDefault();
        $(this).parents('div').find('.mobile-gallerysearchbar #mobile-catsearch').focus();
    });

    // loading messages in tabs
    $body.on('show', '[data-toggle="tab"]', function(e) {
        var id = $(e.target).attr('href');
        if ($(id).length)
            $(id).find('.loadingMsg').removeClass('hidden');//loading message is hidden because of bug in bootstrap where pane that was hidden by hidden-{media} content is shown before moving to the tab
    });
    // main data Caruosel //
    if (typeof $().carousel == 'function' && $('.mainCarousel').length > 0) {
        carousel = $('.mainCarousel');
        carousel.attr('data-interval', 'false');
        carousel.carousel({
            'interval': false
        });
    }

    $('.carousel').not('.nofocus').kmsCarouselFocus();
    $('.carousel-nav a[data-to]').kmsCarouselNav();

    $('input[isrequired]').keyup(function() {
        if ($(this).val().length > 0) {
            $(this).parents('.control-group').removeClass('error');
            $(this).siblings('[class*="help"]').hide();
        }
        else {
            $(this).parents('.control-group').addClass('error');
            $(this).siblings('[class*="help"]').show();
        }

    });

    //side navigation (new) 27/5/13
    var sidrOptions = {
        source: '#sidr',
        renaming: false,
        body: '#globalOuterWrap',
        speed: 200, //in ms must be set
        side: 'left' // must be set
    };
    var windowWidth = $(window).width();

    var onResize = function() {
        if ($(window).width() != windowWidth) {
            // Update the window width for next time
            windowWidth = $(window).width();
            $.sidr('close');
        }
    };
    if (typeof $.sidr === 'function' && typeof window.orientation === "undefined") {
        $(window).bind('resize', GLOBAL_KMS.helpers.throttle(onResize, 500));
    }
    $('#Kbtn-navbar').kmsSidr(sidrOptions);
    $('#Kbtn-navbar').click(function(e) {
        e.preventDefault();
        $(this).toggleClass('active');
        /*if ($(this).hasClass('active')){
         var newBodyWidth = 100 - (100 * $(sidrOptions.source).width() / $(sidrOptions.body).width());
         $(sidrOptions.body).css({
         width: newBodyWidth + '%'
         });
         }*/
    });
    sidrOptions.width = $('.sidr').css('width'); //for IOS/ Android native app
    window.sidrOptions = sidrOptions;
    // better cloning + handling classes to appear only in tablet/phone
    $('ul.added2SidemenuPost > li:not(.divider-vertical)').each(function() {
        var newMenu = $(this).clone();
        $(newMenu).removeClass('dropdown');
        $(newMenu).addClass('rootOnly');
        $('#menu').append($(newMenu));
    });
    $('#menu').find('ul').each(function() {
        $(this).removeClass('dropdown-menu');
    });
    $('#menu').find('a').addClass('navbar-link');
    if (typeof $().kmsDrilldown != 'undefined') {
        $('#menu').kmsDrilldown({
            speed: 'slow',
            saveState: true,
            classActive: 'active',
            classWrapper: 'dd-wrapper',
            showCount: false
        });
    }
    $('#sidr').find('a.dd-parent-a').on('keydown',function(e){
        if (e.which == 39) {
            $(this).next('a.navbar-link').trigger('click');
        }
    });

    mainCarousel = $('.mainCarousel').first();

    /*BootBox Wrapper*/
    $body.on("show",'.bootbox', function () {
        kmsPlayerZindex(-1);
    });
    $body.on("hide",'.bootbox' ,function () {
        //setting focus on the element that spawned the dialog.
        //the use of setTimeout here is to ensure we are the last to activate focus on the element.
        setTimeout(function(){
            $('.activeModal').focus();
            $('.activeModal').removeClass('activeModal');}, 100);

        kmsPlayerZindex(1);
    });

    $('.disabled').kmsInitDisable();

    //fix Sub level navigation not working on Mac Safari
    $('.dropdown').on("mouseenter", 'li.dropdown-submenu', function() {
        openDropDownSubMenu($(this));
    });

    $('.dropdown').on("mouseleave", 'li.dropdown-submenu', function() {
        closeDropDownSubMenu($(this));
    });

    // adds token to each ajax request to prevent csrf attacks
    $.ajaxPrefilter(function(options, originalOptions, jqXHR) {
        var ajax_nonce = $("meta[name=xsrf-ajax-nonce]").attr("content");
        var prefix = '&';
        if (!options.data) {
            options.data = '';
            prefix = '';
        }

        options["beforeSend"] = function(jqXHR){
            // send CSRF token only in same-domain requests (i.e. to KMS)
            if(!options['crossDomain'])
            {
                var ajax_nonce = $("meta[name=xsrf-ajax-nonce]").attr("content");
                jqXHR.setRequestHeader('X-Kms-Nonce', ajax_nonce);
            }
        };
    });

    // add focus to modals
    $body.on('shown', '.modal',  function(){
        $('.modal').focus();
        $('.modal').find("[autofocus]:first").focus();
    });

    // add focus to forms - initial page load
    $("[autofocus]:first").focus();

    // tabs accessibility
    $body.on('shown', 'a[data-toggle="tab"]', function (e) {
        // first page load - make sure that the shown pane tab has the aria-selected=true on it.
        $(e.currentTarget).attr('aria-selected', true);

        // when switching to a different tab - find the 'active' tab and mark the tab as aria-selected.
        var $tabsContainer = $(e.currentTarget).parents('ul');
        $tabsContainer.children('li').each(function(index, item) {
            var selected = false,
                $item = $(item);
            if($item.hasClass('active')) {
                selected = true;
            }

            $item.find('a').attr('aria-selected', selected);
        });

        // add focus to forms inside tabs
        var pane = $(e.target).attr('href');
        $(pane).find("[autofocus]:first").focus();
    });

    // changing accessibility active state on press
    $body.on('click', '[data-toggle="buttons-radio"] button', function(e) {
        $(this.parentElement).find('button').attr("aria-checked", "false");
        this.setAttribute("aria-checked", "true");
    });

    // add expanded to drop down menus
    $body.on('click', '.dropdown-toggle',  function(e){
        var elem = $(e.currentTarget);
        if (elem.attr('aria-expanded') == 'false') {
            elem.attr('aria-expanded', true);

            // remove expanded indication
            $('body').one('click',  function(e){
                elem.attr('aria-expanded', false);
            });
        }
    });

    // focus on first focus-able element in dropdown menus.
    $body.on('keyup', '.dropdown-toggle', function(e) {
        // down arrow
        if(e.keyCode === 40) {
            var $elem = $(e.currentTarget);
            if($elem.attr('aria-controls')) {
                $('#' + $elem.attr('aria-controls') + ' li:first-child a').focus();
            }
        }
    });
});

//this func is overwritten in native-func.js since cordova kdp api is different
function kdpEvaluateWrapper(termToEvaluate, callback){
    if (kdp){
        var evaluatedTerm = kdp.evaluate(termToEvaluate);
        if ($.isFunction(callback)){
            callback(evaluatedTerm);
        }
        else{
            jsLog("kdpEvaluateWrapper: " + callback + " is not a function");
        }
    }
}

function openDropDownSubMenu(subMenu){
    subMenu.children('ul.dropdown-menu').css('display','block');
}

function closeDropDownSubMenu(subMenu){
    subMenu.children('ul.dropdown-menu').css('display','none');
}

function resetCarousel(carousel) {
    var car;
    if (typeof carousel !== 'undefined') {
        car = $('#' + carousel);
    }
    else if (typeof mainCarousel !== 'undefined') {
        car = mainCarousel;
    }
    car.carousel(0).carousel({'interval': false});

    // set the carousel item active class again
    car.find('.carousel-nav a.active').each(function() {
        $(this).removeClass('active');
    });
    car.find('.carousel-nav a[data-to="1"]').addClass('active');

    // use the inner carousel active class - for nested carousels
    car.find('.carousel .item.innerActive').addClass('active');
    car.find('.carousel .item.innerActive').removeClass('innerActive');

    $().kmsGalleryRefresher('slidRefresh');
}

function carouselSearchPage() {
    if (typeof mainCarousel !== 'undefined') {

        // keep the inner carousel active class - for nested carousels
        mainCarousel.find('.carousel .item.active').addClass('innerActive');

        $('#channelTabs li:first a').tab('show');

        var items = $('div.mainCarousel  div.carousel-inner  div.item'); // for the outer carousel only items!
        var count = items.length;
        var searchItem = $('#searchPage').index();
        if (searchItem != false) {
            mainCarousel.carousel(searchItem);//.carousel({'interval': false});
        }
        else {
            mainCarousel.carousel(count - 1);//.carousel({'interval': false});
        }
    }
}

//receives a non mandatory param to indicate the last selected tab
function resetTabs(activeIndex) {
    if(!activeIndex || isNaN(activeIndex)){
        $('.nav-pills:first li:first a').tab('show');
    }else{
        $('.nav-pills:first li:nth-child(' + activeIndex + ') a').tab('show');
    }
}

function kmsDisable(elem){
    $(elem).each(function() {
        $(this).addClass('disabled');
        $(this).on('click', function(e) {
            if ($(this).hasClass('disabled')) {
                e.preventDefault();
                return false;
            }
        });
    });
}

function kmsEnable(elem){
    $(elem).each(function() {
        if ($(this).hasClass('disabled')) {
            return  $(this).removeClass('disabled');
        }
    });
}


/* global ajax loader */
function doAjaxSpin() {
    if (unspinTimeout) clearTimeout(unspinTimeout);
    var stickyClass = '';
    var header = $('#header');
    if (header !== undefined) {
        if (header.height() < $(this).scrollTop()){
            stickyClass = "sticky";
        }
    }

    $('#loaderWrap').remove();
    $('#wrap').before('<div id="loaderWrap" class="' + stickyClass + '"><div id="loaderBkgrd"></div><div id="loader"></div></div>');

    if (Modernizr.csstransitions){
        setTimeout(function(){
            $('#loader').css('width', '99%');
        }, 100);
    }
    else{
        // no css transitions -  requestAnimationFrame
        var start = null;
        var element = $('#loader');
        var spinner = 'global';    

        // stop the loader animation
        $(document).on('kmsLoaderDone', function(){
            spinner = null;
        });

        function step(timestamp){
            if (!start) start = timestamp;
            var progress = timestamp - start;
            var elemWidth = Math.min(progress/200, 100);
            element.css('width', elemWidth + "%");
            if (progress < 20000 && elemWidth < 100 && spinner != null) {
                window.requestAnimationFrame(step);
            }
            else{
                element.css('width', "100%");
            }
        }

        window.requestAnimationFrame(step);
    }
}

var unspinTimeout;

/* stop the ajax loader */
function doAjaxUnspin() {
  //  spinner = null;
    $.event.trigger('kmsLoaderDone');

    $('#loader').css({'transition-duration': '0.4s', 'width' : '100%'});
    if (unspinTimeout) clearTimeout(unspinTimeout);
    unspinTimeout = setTimeout(function(){
        $('#loaderBkgrd').css('height', '0px');
        $('#loader').css('height', '0px');
    }, 400);
}

/* element loader */
KmsElementSpinner = function(element){
    this.element = element;
    this.loader = '<div class="elementLoader"><div class="message">' + translate('Loading') +'&hellip;</div></div>';

    this.start = function(){
        var target = $(element);
        if (target.length > 0) {
            if (target.prop('tagName') == 'TABLE') {
                target.after(this.loader);
            }
            else{
                target.append(this.loader);
            }

            if (!Modernizr.cssanimations){
                // start the loader animation
                $('.elementLoader .message', target).kmsBlinkAnimation();
            }
        }
    };

    this.stop = function(){
        var target = $(element);
        if (target.length > 0) {

            if (!Modernizr.cssanimations){
                // stop the loader animation
                $('.elementLoader .message', target).kmsBlinkAnimation('stop');
            }

            if (target.prop('tagName') == 'TABLE') {
                target.after(this.loader);
                $(element + ' + .elementLoader').remove();
            }
            else{
                $('.elementLoader', target).remove();
            }
        }
    };
}


function elementSpin(element, spinnerSize) {
    var spinner = new KmsElementSpinner(element);
    spinner.start();
    return spinner;
}


/*
 *wrapper for kplayer Z index notification
 */
kmsPlayerZindex = function (value) {
    var $kplayer = $('#kplayer');
    if ($kplayer.length && typeof value == 'number' && typeof $kplayer[0].sendNotification ==='function') {
        $kplayer[0].sendNotification('setPlayerZIndex', {'data': value});
    }
}

function setWysiwyg($wysihtml5CdnUrl) {
    if (typeof $().wysihtml5 != 'undefined') {
        $('.wysiwyg').each(function() {
            var wysiwygObj = $(this).wysihtml5({
                "font-styles": false, //Font styling, e.g. h1, h2, etc. Default true
                "emphasis": true, //Italics, bold, etc. Default true - creates <b>, <i>, <u> tags
                "lists": true, //(Un)ordered lists, e.g. Bullets, Numbers. Default true - creates <ol> <ul> <li> tags
                "html": false, //Button which allows you to edit the generated HTML. Default false
                "link": true, //Button to insert a link. Default true - creates <a> tag
                "image": true, //Button to insert an image. Default true, - creates <img> tag
                'stylesheets': $wysihtml5CdnUrl, //cdn url of the stylesheet
                "color": true, //Button to change color of font - creates <span> tag
                "locale": "current_kms_locale"
            }).removeClass('wysiwyg').addClass('wysiwyg-Active');
            if ($(this).attr('required') === 'required') { // for required descriptions
                $(this).removeAttr('required');
                var wysihtml5Editor = $(this).data('wysihtml5');
                $(this).parents('form:first').on('submit', function() {
                    checkWysihtml5LengthAndValidation(wysihtml5Editor, wysiwygObj)
                })
                window.editor.on('blur', function() {
                    checkWysihtml5LengthAndValidation(wysihtml5Editor, wysiwygObj);
                });
            }
            function checkWysihtml5LengthAndValidation(wysihtml5Editor, wysiwygObj) {
                if (wysihtml5Editor.editor.textareaElement.value.length == 0) {
                    $(wysiwygObj).siblings('span.help-inline').css('color', 'red').show();
                    $(wysihtml5Editor.editor.composer.iframe).css('border-color', 'red');
                    return false;
                }
                else {
                    $(wysiwygObj).siblings('span.help-inline').hide()
                    $(wysihtml5Editor.editor.composer.iframe).css('border-color', '');
                    return true;
                }
            }
        });
    }
}

/**
 *  jquery plugins for kms events
 */

(function($) {

    /**
     *wrapper for sidr
     */
    $.fn.kmsSidr = function(options) {
        if (typeof $.sidr == 'function') {
            $(this).sidr(options);
            $('#sidr').addClass('navbar');
            $('#sidr').children('.sidr-inner').addClass('navbar-inner').removeClass('sidr-inner');
        }
        return this;
    };

    /**
     * check toggles actions in table lists
     */
    $.fn.kmsToggleBatchActions = function() {
        var batchBtns = $(this);
        var checkState = function() {
            if ($('td.checkboxTd input[type="checkbox"]').filter(':checked').filter(':not("[disabled]")').length > 0)
                return batchBtns.children('a,button').removeClass('disabled');
            else
                return batchBtns.children('a,button').addClass('disabled');
        };
        batchBtns.children('a,button').kmsDisabled();
        $('body').on('change', 'td.checkboxTd input[type="checkbox"]', batchBtns, checkState);
        $('input.checkAllChecbox').on('allChange', checkState);
        return this;
    };

    $.fn.showSearch = function(patternSearch) {
        $(this).on('click',function(e) {
            e.preventDefault();
            $(this).parents('div').find(patternSearch).focus();
        });
    };


    /**
     * The method adds a user suggestion auto complete text box.
     * @param filterSelf - by default current user will be filtered from the suggestion list, unless false is value is given.
     * @param filterByRoles - if filteredByRoles is supplied, will filter out users that do not poses one of the roles in the given list
     * @param filterByUserType - if the group member enabled - the parameter will pass to user suggestion
     * @param filterNonInstance - if true, will find users from all partner instances.
     * @returns {*} bootstrap typeahead element(s)
     */
    $.fn.addUserSuggestionElement = function(filterSelf, filterByRoles, filterByUserType, filterNonInstance) {

        if (filterSelf === null) {
            filterSelf = true;
        }

        var filterQuery = '?filterSelf=' + filterSelf;
        if (filterByRoles) {
            filterQuery += '&allowedUserRoles=' + filterByRoles.join();
        }
        if(filterByUserType){
            filterQuery += '&filterByUserType=true';
        }
        if(filterNonInstance){
            filterQuery += '&filterNonInstance=true';
        }

        return $(this).typeahead({
            name: 'users',
            template: '<p>{{label}}</p>',
            engine: Hogan,
            limit: 10,
            remote: window.baseUrl + '/user/usersuggestions/term/%QUERY/format=ajax' + filterQuery
        });
    };

    /**
     * selects text in element while allowing partial select
     */
    $.fn.kmsSelectText = function() {
        var $this = $(this);
        $this.kmsTooltip({'title': translate('Press CTRL-C to copy'), placement: 'top'});
        if ($this.is(':visible') === false) {
            $('body').one('slid', function() {
                if ($this.is(':visible')) {
                    $this.focus();
                }
            });
        }
        else {
            $this.focus();
        }
        $this.focus(function(e) {
            e.target.select();
            $(e.target).one('mouseup', function(e) {
                e.preventDefault();
            });
        });
        return this;
    };

    /**
     *  makes a click refresh the gallery when the shown/slid event was triggered.
     */
    $.fn.kmsGalleryRefresher = function(action) {
        if (typeof $().isotope != 'undefined') {
            if (typeof action != 'undefined') {
                if (action == 'force')
                    $('.isotope').isotope('reLayout');
                else if (action == 'slidRefresh') {
                    $('.carousel').on('slid', function() {
                        $('.isotope').isotope('reLayout');
                    });
                }
            }
            else {
                $(this).click(function() {
                    $('body').on('shown slid', function() {
                        $('.isotope').isotope('reLayout');
                    });
                });
            }
        }
        return this;
    };

    /**
     *  mark/unmark the link as disabled - this is used for toggling
     */
    $.fn.kmsDisabled = function(action) {
        return this.each(function() {
            if ($(this).hasClass('disabled')) {
                return  $(this).removeClass('disabled');
            }
            else {
                $(this).addClass('disabled');
                $(this).on('click', function(e) {
                    if ($(this).hasClass('disabled')) {
                        e.preventDefault();
                        return false;
                    }
                });
            }
        });
    };

    /*
     this is used when initializing a disabled element
     */
    $.fn.kmsInitDisable = function (action) {
        $(this).on('click', function(e) {
            if ($(this).hasClass('disabled')) {
                e.preventDefault();
                return false;
            }
        });
    }
    /**
     *  add a psedu anchor behaviour which is depandent on view mode (desktop/tablet/phone)
     */
    $.fn.kmsMQHref = function(viewMode) {
        var $this = $(this);
        var psedu = $('<i/>').insertAfter($this).addClass('visible-' + viewMode);
        if ($this.attr('data-href')) {
            $this.click(function() {
                if (psedu.is(':visible')) {
                    window.location = $(this).attr('data-href');
                }
            });
        }
        return this;
    };
    /**
     *  mark the table as having checkAll functionality
     */
    $.fn.kmsCheckAllTable = function() {
        this._kmsBulkData = '';
        var table = $('input.checkAllChecbox', this).parents('table');

        // check all
        $('input.checkAllChecbox', this).on('click', function() {
            table.find('td.checkboxTd input').not('[disabled="disabled"]').prop('checked', $(this).prop('checked'));
            $(this).trigger('allChange');
        });
        //mark inputs as handeled and  keep bulk data
        var $inputs = table.find('input[type="checkbox"]').not('[dataBulkEnabled]').not('[disabled="disabled"]');
        table.kmsCheckAllTable.bindFunction($inputs);

        return this;
    };
    $.fn.kmsCheckAllTable.bindFunction = function($inputs) {
        $inputs.each(function() {
            $(this).attr('dataBulkEnabled', true);
            $(this).on('click', $().kmsCheckAllTable.clickFunction);
        });
    };
    $.fn.kmsCheckAllTable.clickFunction = function() {
        var items = $('.checkboxTd input:checked').not('[disabled="disabled"]');
        var ar = [];
        items.each(function(index) {
            if($(this).attr('id')){
                ar.push($(this).attr('id'));
            }
        });
        $().kmsCheckAllTable.bulkDataClear();
        $().kmsCheckAllTable.bulkData(ar.join(','));

    };

    $.fn.kmsCheckAllTable.bulkData = function(data) {
        if (data) {
            this._kmsBulkData = data;
        }

        if (typeof this._kmsBulkData == 'undefined') {
            this._kmsBulkData = '';
        }
        return this._kmsBulkData;
    };

    $.fn.kmsCheckAllTable.bulkDataClear = function() {
        this._kmsBulkData = '';
    };

    /**
     *   switch based checkboxes event
     */
    $.fn.checkboxSwitch = function(onChange) {
        if ($(this).attr('data-url')) {
            $(this).on('change', function(e) {
                var value = (this.checked) ? true : false;
                if (typeof(onChange)=='function') onChange(value);
                var url = $(this).attr('data-url') + '/value/' + value + '?format=ajax';
                $.getJSON(url, asyncCallback).error(transportError);
            });
        }
    };

    /**
     *  Gallery grid - wraps isotope
     */
    $.fn.kmsIsotope = function(options, element, callback) {
        var gallery = $(this);
        if (gallery.is('ul') && typeof $().isotope !== 'undefined') {
            if (options !== undefined) {
                if (options === 'appended') {
                    // appended - get the new elements if not provided
                    element = getNewElements(element);
                }
                else if (options !== 'reLayout') {
                    // extend the options
                    options = $.extend({}, $.fn.kmsIsotope.defaults, options);
                }
                if (options === 'reLayout') {
                    return gallery.isotope().isotope(options);
                }
                return element.imagesLoaded(function() {
                    return gallery.isotope().isotope(options, element, callback);
                });
            }
            else {
                // default - create new element
                if (!($(this).hasClass('isotope'))) {
                    var spinner = elementSpin(gallery.parent());
                    $(gallery).imagesLoaded(function() {
                        if (typeof spinner != 'undefined')
                            spinner.stop();
                        gallery.isotope($.fn.kmsIsotope.defaults);
                    });
                }
                return this;
            }
        }
        return this;

        function getNewElements(element) {
            if (typeof element == 'undefined') {
                element = $("li.galleryItem:not(.isotope-item)");
            }
            return element;
        }

    };
    // kmsIsotope Plugin defaults
    $.fn.kmsIsotope.defaults = {
        itemSelector: '#gallery li.hidden-phone',
        layoutMode: 'fitRows'
    };

    /**
     *  activate the accordion
     */
    $.fn.kmsAccordion = function() {
        this.on('show hidden', function(e) {
            if ($(e.target).hasClass('collapse')) {
                //because of a firefox bug of double show events
                var trigger = $(e.target).siblings().find('.accordion-toggle i');
                var accordionToggle = $(e.currentTarget).find('.accordion-toggle');
                if (e.type === 'show') {
                    trigger.removeClass('icon-plus-sign').addClass('icon-minus-sign');
                    accordionToggle.attr("aria-expanded", "true");
                }
                else {
                    trigger.removeClass('icon-minus-sign').addClass('icon-plus-sign');
                    accordionToggle.attr("aria-expanded", "false");
                }

                if ($('ul#gallery.thumbnails').length > 0) { // for gallery pages (channel etc)
                    var textChildHeight = $(e.target).find('div.user_wrapper').actual('height');
                    var parentLI = $(this).parents('li.galleryItem');
                    if (e.type == 'hidden') { //hide
                        parentLI.find('.accordion-inner').css('display', 'none');
                        if ($("html[class~='ie8'],[class~='ie9']").length > 0) {
                            parentLI.css('height', '');
                            setTimeout(function() {
                                $('ul#gallery').kmsIsotope('reLayout');
                            }, 200);
                        }
                        else {
                            parentLI.css('height', '');
                            $('ul#gallery').kmsIsotope('reLayout');
                        }
                    }
                    else if (e.type === 'show') { //show
                        var baseHeight = $('.thumbnail', parentLI).height();
                        if ($(e.target).parents('#galleryGrid.short').length) {
                            baseHeight = 50;
                        }
                        parentLI.find('.accordion-inner').css('display', 'block');
                        var fullheight = baseHeight + textChildHeight + $(e.target).find('div.accordion-inner').actual('height') + 10;
                        parentLI.css('height', fullheight);
                        $('ul#gallery').kmsIsotope('reLayout');
                    }
                }
                else if ($('table.mymediaTable').length > 0) { // for mymedia pages
                    var parentContainer = $(this).parents('div.fullsize');
                    if (e.type === 'hidden') {
                        parentContainer.css('height', '');
                    }
                    if ($(e.target).hasClass('contentLoaded')) {
                        if (e.type !== 'hidden') {
                            var childheight = 0;
                            $(e.target).children().each(function() {
                                childheight += $(this).actual("height");
                            });
                            var parentHeight = parentContainer.actual("height");
                            if (childheight > (parentHeight - 52)) { // the set amount of px for title and stats
                                var fullheight = childheight + parentHeight;
                                parentContainer.css('height', fullheight);
                            }
                        }
                    }
                }
            }
        });
        //adding to accordion toggle aria-explanded = false as default
        $(this).find(".accordion-toggle").attr("aria-expanded", "false");
        return this;
    };


    /**
     *  reset the main carousel
     */
    $.fn.kmsMainCarouselReset = function(carousel) {
        this.on('click', function(event) {
            resetCarousel(carousel);
        });
        return this;
    };

    /**
     *  reset the tabs
     */
    $.fn.kmsMainTabsReset = function() {
        this.on('click', function(event) {
            resetTabs();
        });
        return this;
    };

    /**
     *  Perform a live search (for any string length)
     */
    $.fn.kmsSearchForm = function() {
        var that = this;
        var charsToReplaceRegex = /\/|\\|%2F/g; // remove these chars: /, \ and %2F from the search in order to prevent 404 errors
        var reset = ($(this).attr('data-reset-carousel') == 'true' || $(this).attr('data-reset-carousel') == '1');
        var submit = ($(this).attr('data-submit-on-clear') == 'true' || $(this).attr('data-submit-on-clear') == '1');
        var instantSearch = window.kmsInstantSearch;

        if(instantSearch) {
            this.on('keyup.kmsSearchForm', 'input.kmsSearch', function (event) {
                if (event.keyCode === 9 || event.keyCode === 16) {
                    return false;
                }

                handleSearch(this);
            });
        }

        // enter pressed
        this.on('keydown.kmsSearchForm', 'input.kmsSearch', function(event) {
            if (event.keyCode == 13){ 
                handleSearch(this);

                // prevent the default form submission
                event.preventDefault();
                return false;
            }
        });

        // search icon
        this.on('click.kmsSearchForm', '#search-icon', function(event) {
            var element = $(this).next('input.kmsSearch');
            handleSearch(element[0]);
        });

        // clear icon
        this.on('click.kmsSearchForm', '.clear-icon', function() {
            // clear the search field
            $(this).parents('div.input-append').find('input').val('');
            $(this).addClass('hidden');
            resetForm($(this));
        });

        function handleSearch(element){
            var len = $(element).val().length;
            if (len > 0) {
                performSearch(element);
            }
        }

        function performSearch(element){
            if ($('div#searchPage.active').length == false) { //check if wer're already on the search page
                $('.carousel-nav a.active').each(function() { // makes the carousel nav buttons unpressed
                    $(element).removeClass('active');
                });
                if (reset == true) {
                    resetTabs();
                    carouselSearchPage(); // finds the searchpage
                }
            }
            $('#searchTerm').text($(element).val().replace(charsToReplaceRegex,'')); //updates the title for the search
            $(element).parents('div.input-append').find('.clear-icon').removeClass('hidden'); // adds the clear icon

            var _this = element;
            _this.value = _this.value.replace(charsToReplaceRegex,'');

            if(instantSearch) {
                clearTimeout($(this).data('searchTimeout'));
                $(this).data('searchTimeout', setTimeout(function() {
                    kmsSendAjaxForm($(_this).parents('form').first());
                }, 800));
            }
            else {
                kmsSendAjaxForm($(_this).parents('form').first());
            }
        }

        // reset the search form
        function resetForm(elem) {
            //check if the form element has data-active-tab attribute for reset tabs to the previously selected
            var formElement = elem.parents('form').first();
            var activeIndex = formElement.attr('data-active-tab');

            // reset the search keyword if its in the form action
            var formAction = formElement.attr('action');
            formAction = formAction.replace(/(keyword\/\w+\/?)/,"");
            formElement.attr('action', formAction);

            // reset the main carousel if necessary
            if (reset === true) {
                resetTabs(activeIndex);
                resetCarousel();
                elem.kmsGalleryRefresher('force');
            }
            // submit the form if necessary
            if (submit === true) {
                formElement.submit();
            }
        }

        return this;
    };

    $.fn.kmsDatepicker = function(opt) {
        var options = {
            autoclose: true,
            todayHighlight: true
        };
        $.extend(options, opt);
        $(this).datepicker(options);
        return this;
    };
    $.fn.kmsHighlight = function(term) {

        if (term.length > 1) {
            this.each(function() {
                highlight(this, term, 'searchTerm');
            });
        }

        function highlight(elem, str, className) {
            //stripHTMLtags that are the <span> from the prev search hightlight,
            //so each search will do it on clean html without the last highlight
            elem.innerHTML = elem.innerHTML.replace(/(<([^>]+)>)/ig,"");
            var regex = new RegExp(escapeRegExp(str), "gi");
            elem.innerHTML = elem.innerHTML.replace(regex, function(matched) {
                return "<span class=\"" + className + "\">" + matched + "</span>";
            });
        }

        function escapeRegExp(string) {
            return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
        }

        return this;
    };

    /**
     *  tags
     */
    $.fn.kmsTags = function(options) {

        var searchControllerUrl = $('#loadTagsUrl').val();

        if (typeof ($().select2) != 'undefined' && $('html').hasClass('ie7') !== true) {

            var settings = $.extend({
                tags: true,
                tokenSeparators: [",", ";"],
                multiple: true,
                minimumInputLength: 3,
                createSearchChoice: function (term) {
                    return {
                        id: $.trim(term),
                        text: $.trim(term) + ' (' + translate('new tag') +')'
                    };
                },
                ajax: {
                    url : searchControllerUrl,
                    cache: "true",
                    dataType: 'json',
                    data: function (term, page) {
                        return {
                            q: term
                        };
                    },
                    results: function (data, page) {
                        return {
                            results: data
                        };
                    }
                },
                initSelection: function (element, callback) {
                    var data = [];

                    function returnTagsTobox(string, separator) {
                        var val, i, l;
                        if (string === null || string.length < 1) return [];
                        val = string.split(separator);
                        for (i = 0, l = val.length; i < l; i = i + 1) val[i] = $.trim(val[i]);
                        return val;
                    }
                    $(returnTagsTobox(element.val(), ",")).each(function () {
                        data.push({
                            id: this,
                            text: this
                        });
                    });
                    callback(data);
                }

            }, options);

            this.select2(settings);
            this.siblings( ".help-block" ).css('margin-right','100px');
        }

        // add accessibility roles
        var select2Container =  this.siblings('.select2');
        select2Container.find('.select2-choices').attr('aria-role','listbox').attr('id','tags-list').attr('tabindex','0');
        select2Container.find('.select2-choices li').attr('aria-role','option').attr('aria-selected','true');
        select2Container.find('.select2-choices li').each(function(index){
            $(this).attr('id','tag-' + index).attr('tabindex','0');
        });
        // last <li> is a combobox, not an option
        var comboBox = select2Container.find('.select2-choices li').last();
        comboBox.attr('aria-selected', '').attr('aria-role','').attr('tabindex','-1');
        comboBox.find('input').attr('aria-role','combobox').attr('aria-owns','tags-list').attr('aria-label',translate("Please enter %1 or more %2", [3, "characters"]));
        // mark active descendant
        this.on('choice-selected', function (evt) {
            var focused = select2Container.find('.select2-choices li.select2-search-choice-focus');
            select2Container.find('.select2-choices').attr('aria-activedescendant', focused.attr('id'));
        });

        return this;
    };

    /**
     * category tree
     */
    $.fn.kmsCategoryTree = function (){
        //sign up for change event for root categories in tree in order to check/uncheck all their nested categories
        $($($(this).children('ul')).children('li')).each(function(){
            $(this).change(function(e){
                $rootCat = $(this).children().children().children('input:checkbox');
                $($(e.target).parents('li').next('ul').children('li')).each(function(){
                    var $nestedCat = $(this).children().children().children('input:checkbox');
                    if ($rootCat.prop('checked') != $nestedCat.prop('checked')){
                        $nestedCat.click();
                    }
                })
            })
        });

        //sign up for change event on the nested categories in order to check/uncheck their root category
        $($($(this).children('ul')).children('ul')).each(function(){
            $(this).change(function(e){
                $nestedCatIsChecked = false;
                $(e.target).closest('ul').children('li').each(function(){
                    $nestedCat = $(this).children().children().children('input:checkbox');
                    if (($nestedCat).prop('checked')){
                        $nestedCatIsChecked = true;
                        return;
                    }
                })

                //find the root cat and check/uncheck it
                if ($nestedCatIsChecked){
                    $(this).prev('li').children().children().children('input:checkbox').attr('checked','checked');
                }
                else{
                    $(this).prev('li').children().children().children('input:checkbox').removeAttr('checked');
                }
            })
        });
    }

    /**
     *  my media view type
     */
    $.fn.kmsViewModeSwitch = function(elm) {
        $(this).on('click', '.shortView', function() {
            $(elm).addClass('short');
            $(elm).removeClass('full').removeClass('tableClass');
            $('#myMediaCarousel').removeClass('tableClass');
            globalParameters.setData('view', 'short');
        });
        $(this).on('click', '.longView', function() {
            $(elm).addClass('full');
            $(elm).removeClass('short').removeClass('tableClass');
            $('#myMediaCarousel').removeClass('tableClass');
            globalParameters.setData('view', 'full');
        });
        $(this).on('click', '.tableView', function() {
            $(elm).addClass('tableClass');
            $(elm).removeClass('full').removeClass('short');
            $('#myMediaCarousel').addClass('tableClass');
            globalParameters.setData('view', 'tableClass');
        });
        return this;
    };

    /**
     *  multiple view type on category/search
     */
    $.fn.kmsMultipleViewModeSwitch = function(elm) {
        $(this).on('click', '.shortView', function() {
            $(elm).removeClass('full').removeClass('grid').removeClass('tableClass').addClass('short');
            $('.accordion-body').css('height','0px').removeClass('collapse').removeClass('in').addClass('collapse');
            $('.accordion-inner').css('display','none');
            $('li.galleryItem').css('height','');
            $('i.icon-minus-sign').addClass('icon-plus-sign').removeClass('icon-minus-sign');
            $('a.accordion-toggle').addClass('collapsed');
            $('#galleryHolder').removeClass('tableClass');
            $('#gallery').isotope({ layoutMode: 'straightDown' });
            $('#gallery').isotope('reLayout');
        });
        $(this).on('click', '.longView', function() {
            $(elm).removeClass('short').removeClass('grid').removeClass('tableClass').addClass('full');
            $('.accordion-body').css('height','auto').removeClass('collapse').removeClass('in');
            $('.accordion-inner').css('display','block');
            $('li.galleryItem').css('height','');
            $('i.icon-plus-sign').addClass('icon-minus-sign').removeClass('icon-plus-sign');
            $('a.accordion-toggle').removeClass('collapsed');
            $('#galleryHolder').removeClass('tableClass');
            $('#gallery').isotope({ layoutMode: 'straightDown' });
            $('#gallery').isotope('reLayout');
        });
        $(this).on('click', '.gridView', function() {
            $(elm).removeClass('full').removeClass('short').removeClass('tableClass').addClass('grid');
            $('.accordion-body').css('height','0px').removeClass('collapse').removeClass('in').addClass('collapse');
            $('.accordion-inner').css('display','none');
            $('li.galleryItem').css('height','');
            $('i.icon-minus-sign').addClass('icon-plus-sign').removeClass('icon-minus-sign');
            $('a.accordion-toggle').addClass('collapsed');
            $('#galleryHolder').removeClass('tableClass');
            $('#gallery').isotope({ layoutMode: 'fitRows' });
            $('#gallery').isotope('reLayout');
        });
        $(this).on('click', '.tableView', function() {
            $(elm).removeClass('full').removeClass('short').removeClass('grid').addClass('tableClass');
            $('#galleryHolder').addClass('tableClass');
            $('.accordion-body').css('height','0px').removeClass('collapse').removeClass('in').addClass('collapse');
            $('.accordion-inner').css('display','none');
            $('li.galleryItem').css('height','');
            $('i.icon-minus-sign').addClass('icon-plus-sign').removeClass('icon-minus-sign');
            $('a.accordion-toggle').addClass('collapsed');
            $('#gallery').isotope({ layoutMode: 'straightDown' });
            $('#gallery').isotope('reLayout');
        });
        return this;
    };


    /**
     *  kms tooltips. just a wrapper for tooltip.
     */
    $.fn.kmsTooltip = function(options) {
        var $html = $("html");
        if($html.hasClass('ie7') || $html.hasClass('ie8') || $html.hasClass('ie9')) {return "top";};

        if (window.matchMedia("(min-width: 415px)").matches){ //everything bigger then iPhone6Plus portrait
            var settings = $.extend({
                delay: {show: 300, hide: 0},
                container: 'body',
                placement: function(a, element) {
                    if ($(element).attr('data-placement')) {
                        return $(element).attr('data-placement');
                    }
                    else {
                        var position = $(element).position();
                        if (position.left > 515) {
                            return "left";
                        }
                        if (position.left < 515) {
                            return "right";
                        }
                        if (position.top < 110) {
                            return "bottom";
                        }
                        return "top";
                    }
                }
            }, options);

            var result = this.tooltip(settings);
            result.attr('aria-label', settings.title);
            return result;
        }
    };


    /**
     *  kms ReadMore (v2). for use only with the partial readmore.phtml that creates the required links.
     *  it is a simple event binding for readmore/readless links with support of the shownWhenExpanded class on sibling elements
     *  (even without shortened text)
     */
    $.fn.kmsReadMore = function() {
        var $el = $(this);
        var $shownWhenExpandedObj = $(this).parents('.expandable').find('.shownWhenExpanded');
        var $readMoreLink = $(this).find('.readmore');
        var $readLessLink = $(this).find('.readless');
        var $shortText = $(this).find('.shortened');
        var $fullText = $(this).find('.full');

        if ($shownWhenExpandedObj.length > 0) { //check if we have an additional object to show/hide
            var shownWELength = $.trim($shownWhenExpandedObj.text().length); // check if the object has content
            if (shownWELength > 0) { // in the future we can show/hide  sub items by length
                $readLessLink.remove().appendTo($shownWhenExpandedObj.last());
                $shownWhenExpandedObj.slideToggle();

            }
        }
        else {
            if ($($readMoreLink).hasClass('show')) { // no showWhenExpanded and no readmore - remove links
                $readLessLink.remove();
                $readMoreLink.remove();
            }
        }

        $readMoreLink.click(function() { // event for readmore
            $el.trigger('expanded');
            $shortText.hide();
            $fullText.slideToggle();
            if ($(this).hasClass('show')) // if only ShownWhenExpanded
            {
                $(this).toggleClass('hidden');
            }
        });
        $readLessLink.click(function() { // event for readless
            $el.trigger('contracted');
            $shortText.show();
            $fullText.slideToggle();
            if ($($readMoreLink).hasClass('show'))// if only ShownWhenExpanded
            {
                $($readMoreLink).toggleClass('hidden');
            }
        });

        $(this).parents('.expandable').on('expanded contracted', function() {  // event for sub items
            $shownWhenExpandedObj.slideToggle();
        });
        return this;
    };

    /**
     *  helper function to calculate object size in cross browser manner
     */
    $.fn.assocArraySize = function(obj) {
        var size = 0, key;
        for (key in obj) {
            if (obj.hasOwnProperty(key))
                size++;
        }
        return size;
    };

    $.fn.formMultiElement = function() {
        $('.btn', this).on('click', function(){
            $(this).siblings(':input').last().after($(this).siblings(':input').last().clone().val(''));
        });
        return this;
    };

    $.fn.expandButtonToggleClass = function(){
        var $this = $(this);
        $this.each(function(){
            if ($(this).is('i')){
                $(this).on('click', function(){
                    $(this).toggleClass('icon-plus-sign');
                    $(this).toggleClass('icon-minus-sign');
                });
            }
            else if ($(this).prev().is('i')){
                $i = $(this).prev('i');
                $(this).on('click', function(){
                    $i.toggleClass('icon-plus-sign');
                    $i.toggleClass('icon-minus-sign');
                });
            }
        });

        return this;
    };

    $.fn.kmsCarouselNav = function(){
        $(this).each(function(){
            $(this).click(function(q) {
                var _this = this;
                if (!$(this).hasClass('disabled')){
                    q.preventDefault();
                    $('.carousel-nav a.active').each(function() {
                        $(this).removeClass('active');

                        if ($(this).attr('role') == 'tab') {
                            $(this).attr('aria-selected', false).attr('tabindex','-1');
                        }
                    });
                    $('.js-dropdown-container').find("li").each(function() {

                        // minimized dropdown menu, if clicked, make
                        // sure not to remove the active class
                        // from the clicked element.

                        if ( $(this).find("a").data("id") === $(_this).data("id") ) {
                            $(this).addClass("active");
                            return;
                        }
                        $(this).removeClass('active');

                        if ($(this).attr('role') == 'tab') {
                            $(this).attr('aria-selected', false).attr('tabindex','-1');
                        }
                    });
                    $(this).addClass('active');

                    if ($(this).attr('role') == 'tab') {
                        $(this).attr('aria-selected', true).removeAttr('tabindex');
                    }

                    var clickedPage = $(this).attr('data-to') - 1;
                    var carousel;
                    var car = $(this).parentsUntil(".carousel-nav").parent().attr("data-carusel");
                    if (typeof car != 'undefined') {
                        carousel = $('#' + car).carousel({interval: false});
                    }
                    else {
                        carousel = $('.mainCarousel').carousel({interval: false});
                    }
                    carousel.carousel(clickedPage);
                }
            });
        });
        return this;
    };

    $.fn.kmsCarouselFocus = function(){
        $(this).each(function(){
            $(this).on('slid', function(event){
                var item = $(event.target).find('.item.active');
                item.focus();
                item.find("[autofocus]:first").focus();

                // prevent event propagation for parent carousels
                event.stopPropagation();
                return false;
            });
        });
    };

    $.fn.kmsCarouselNavUpdate = function(carouselId, actions){

        // get the carousel
        var carousel = $(carouselId);
       
        // update the carosel actions data-to
        $.each(actions, function(index, action){
            var control = $('a#tab-' + action.id);
            // update only links that control the carousel
            if (control.attr('data-to') != undefined) {
                var pane = $('.carousel-inner .item #' + action.dest, carousel);
                var index = pane.parent().prevAll().length + 1;
                control.attr('data-to', index).kmsCarouselNav();
            }
        });

        return this;
    };

    // animated ellipsis for loading elements
    $.fn.kmsEllipsisLoad = function(action) {
        var that = this;

        if ( action === 'stop') {
            $(this).find('.elloading').remove();
        }
        else {
            $(this).each(function(){
                $(this).append('<span class="elloading"><span>.</span><span>.</span><span>.</span></span>');
            });
            
            if (!Modernizr.cssanimations){
                var start = null;

                function step(timestamp){
                    if (!start) start = timestamp;

                    $('.elloading span', that).each(function(index){
                        var opacity = '';
                        var progress = timestamp - start;

                        progress = Math.max(progress - index * 200, 0);

                        if (progress < 280) {
                            opacity = Math.min(20 + progress/10*3, 100);
                        }
                        if (progress >= 280) {
                            opacity = Math.max(120 - progress/10 , 20);
                        }
                        if (progress > 1400 ) {
                            start = timestamp;
                        }

                        $(this).css('opacity', opacity/100);
                    });

                    // check that the element is on the dom before continuing
                    if ($('.elloading span', that).length) {
                        window.requestAnimationFrame(step);
                    }
                }
                window.requestAnimationFrame(step);
            }
        }
        return this;
    };

    // add blinking animation to an element
    $.fn.kmsBlinkAnimation = function(action) {
        var plugin = this;
        if ( action === 'stop') {
            $(plugin).data('blinkAnimation',false);
        }
        else {
            var start = null;
            $(plugin).data('blinkAnimation',true);

            function step (timestamp){
                if (!start) start = timestamp;
                var progress = timestamp - start;
                var opacity = '';

                if (progress < 1000) {
                    opacity = Math.min(100 - progress/10, 100);
                }
                if (progress >= 1000) {
                    opacity = Math.min(progress/10 - 100, 100);
                }
                if (progress > 2000 ) {
                    start = timestamp;
                }

                $(plugin).css('opacity', opacity/100);

                if ($(plugin).data('blinkAnimation')) {
                    window.requestAnimationFrame(step);
                }
                else{
                    $(plugin).css('opacity', 100);
                }
            }

            window.requestAnimationFrame(step);
        }
        return this;
    };

    // entry metadata + tabs loading message
    var KmsEntryMetadataMssage = function(element, options){
        this.element = element;
        this.options = options;
        this.data = {'metadata': null, 'tabs': null};    

        // change messages, and fade out
        var done = function(){
            if (!Modernizr.cssanimations){
                $(element).find('.msg').kmsBlinkAnimation('stop');
            }
            $(element).remove();
        }

        // init the object with the loading mesage
        this.init = function(){
            $(element).append('<span class="msg">' + options.msg + '</span>');
            if (!Modernizr.cssanimations){
                $(element).find('.msg').kmsBlinkAnimation();
            }
        }

        // mark metadata received
        this.metadataReceived = function(){
            this.data['metadata'] = true;

            if (this.data['metadata'] && this.data['tabs']) {
                done();
            }
        }

        // mark tabs received
        this.tabsReceived = function(){
            this.data['tabs'] = true;

            if (this.data['metadata'] && this.data['tabs']) {
                done();
            }
        }
    }

    // entry metadata + tabs loading message plugin
    $.fn.kmsEntryMetadataMssage = function(option){
        var plugin = this;
        var data = $(plugin).data('kmsEntryMetadataMssage');
        var options = $.extend({}, $.fn.kmsEntryMetadataMssage.defaults, typeof option == 'object' && option);
        var action = typeof option == 'string' ? option : 'init';

        if (!data) $(plugin).data('kmsEntryMetadataMssage', (data = new KmsEntryMetadataMssage(this, options)));
        data[action]();

        return this;        
    }
    $.fn.kmsEntryMetadataMssage.defaults = {
        msg: '',
        doneMsg: ''
    }

    // keyboard interaction for dropdown menus with hover (main menu)
    $.fn.kmsDropdownKeyboardEvents = function(options){
        var settings = $.extend({
            openKey : 40,
            closeKey : 27,
            nextKey: 40,
            prevKey: 38
        }, options);

        this.on('keydown', function(e){
            switch (e.which){
                case settings.openKey:
                    if ($(this).hasClass('dropdown-toggle')) {

                        if (!$(this).parent('li').hasClass('open')) {
                            $(this).trigger('mouseover');
                            e.preventDefault();
                        }
                        $(this).find('+ ul.dropdown-menu li:first > a').focus();
                    }
                break;
                case settings.closeKey:
                case 27:
                    $(this).trigger('mouseout');
                    $(this).parent('li').parent('ul').parent('li').parent('ul').parent('li').find('> a').trigger('mouseover');
                    $(this).parent('li').parent('ul').parent('li').find('> a').focus();
                break;
                case settings.nextKey:
                    $(this).parent('li').find('+ li > a').focus();

                    e.preventDefault();
                    e.stopPropagation();
                break;
                case settings.prevKey:
                    $(this).parent('li').prev().find('> a').focus();

                    e.preventDefault();
                    e.stopPropagation();
                break;
            }
        });

        return this;
    }

    $.fn.kmsTimepicker = function(options) {
        var settings = $.extend({
            timeFormat: 'g:i A',
            step: 15,
            closeOnWindowScroll: true,
            className: 'kms-timepicker-ui-wrapper'
        }, options),
            $this = $(this);

        $this.timepicker(settings);

        // when focusing the element, save a 'copy' of the last valid time, so that if an incorrect value is inserted, we could use it.
        $this.on('focus', function(e) {
            var $targetElement = $(e.currentTarget);
            $targetElement.data('lastValidTime', $targetElement.val());
        });
        $this.on('blur', function(e) {
           var $targetElement = $(e.currentTarget);
           if($targetElement.val() === '') {
               $targetElement.timepicker('setTime', $targetElement.data('lastValidTime'));
           }
        });
        $this.on('timeFormatError', function(e) {
            var $targetElement = $(e.currentTarget);
            $targetElement.timepicker('setTime', $targetElement.data('lastValidTime'));
        });

        // hide the timepicker when trying to input text (i.e. when not navigating up/down using the arrow keys).
        $this.on('keydown', function(e) {
            if(e.keyCode !== 40 && e.keyCode !== 38) {
                $(e.currentTarget).timepicker('hide');
            }
        });


    }

}(jQuery));

// for documentation see docs/js/kms_kWidgetJsLoader
window.kms_kWidgetJsLoader = {
    _players: {},
    _callbacks: [],
    _loadedPlayer: false,
    _callcallbacks: function() {
        for (var i in this._callbacks) this._callbacks[i]();
        this._callbacks = [];
    },
    loadedElsewhere: function(playerId, partnerId) {
        if (typeof(partnerId) == 'undefined' || partnerId == '') partnerId = window.kms_kWidgetJsLoader_partnerId;
        var id = '_'+partnerId+'_'+playerId;
        if (typeof(this._players[id]) == 'undefined') this._players[id] = {'status': 'new'};
        var player = this._players[id];
        player.status = 'loaded';
        this._callcallbacks();
        this._loadedPlayer = true;
    },
    load: function(playerId, callback, partnerId){
        if (typeof(partnerId) == 'undefined' || partnerId == '') partnerId = window.kms_kWidgetJsLoader_partnerId;
        var id = '_'+partnerId+'_'+playerId;
        if (typeof(this._players[id]) == 'undefined') this._players[id] = {'status': 'new'};
        var player = this._players[id];
        if (this._loadedPlayer) {
            // currently, we don't support loading another player js code in the same page
            player.status = 'loaded';
            callback();
        } else if (player.status == 'new') {
            player.status = 'loading';
            player.callbacks = [callback];
            var url = window.kms_kWidgetJsLoader_baseurl;
            url = url.replace(/\(\(PARTNER_ID\)\)/g, partnerId);
            url = url.replace(/\(\(PLAYER_ID\)\)/g, playerId);
            var _this = this;
            $.getScript(url, function(){
                player.status = 'loaded';
                for (var k in player.callbacks) player.callbacks[k]();
                _this._callcallbacks();
                _this._loadedPlayer = true;
            });
        } else if (player.status == 'loading') {
            player.callbacks.push(callback);
        } else {
            callback();
        }
    },
    thumbEmbed: function(playerId, params) {
        kms_kWidgetJsLoader.load(playerId, function(){
            kWidget.thumbEmbed(params);
        });
    },
    embed: function(playerId, params) {
        kms_kWidgetJsLoader.load(playerId, function(){
            kWidget.embed(params);
        });
    },
    onkWidgetLoad: function(callback) {
        if (!this._loadedPlayer) {
            this._callbacks.push(callback);
        } else {
            callback();
        }
    }
};
if (typeof(kms_kWidgetJsLoader_loadedElsewherePlayerId) != 'undefined') kms_kWidgetJsLoader.loadedElsewhere(kms_kWidgetJsLoader_loadedElsewherePlayerId);


/**
 * Gets a param from the search part of a URL by name.
 * @param {string} param URL parameter to look for.
 * @return {string|undefined} undefined if the URL parameter does not exist.
 */
function getURLParameter(param) {
    if (!window.location.search) {
        return;
    }
    var m = new RegExp(param + '=([^&]*)').exec(window.location.search.substring(1));
    if (!m) {
        return;
    }
    return decodeURIComponent(m[1]);
}

/**
 * Gets a param from the path part of a URL by name.
 * @param {string} param URL parameter to look for.
 * @return {string|undefined} undefined if the URL parameter does not exist.
 */
function getURLParam(param){
    if (!window.location.pathname) {
        return;
    }

    var pathArray = window.location.pathname.split( '/' );
    for (i = 0; i < pathArray.length; i++) {
        if (pathArray[i] == param) {
            return decodeURIComponent(pathArray[i+1]);
        }
    }

    return;
}

/**
 * Gets a param from the path and the search parts of a URL by name.
 * @param {string} param URL parameter to look for.
 * @return {string|undefined} undefined if the URL parameter does not exist.
 */
function getParamFromUrl(param){
    var param = getURLParameter(param);
    if (param != undefined) {
        return param;
    }
    else{
        return getURLParam(param);
    }
}
