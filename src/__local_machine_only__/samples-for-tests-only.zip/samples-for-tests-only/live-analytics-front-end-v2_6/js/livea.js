/*! KMC Live Analytics - v2.6.0 - 2018-03-19
* https://github.com/kaltura/LiveAnalytics
* Copyright (c) 2018 Atar Shadmi; Licensed GNU */
'use strict';


// Declare app level module which depends on filters, and services
var liveAnalytics = angular.module('liveAnalytics', [
	'ngRoute',
	'pascalprecht.translate',
	'analyticsFilters',
	'analyticsServices',
	'analyticsDirectives',
	'analyticsControllers',
	'analyticsFilters'
]);

liveAnalytics.config(['$routeProvider', '$translateProvider', function($routeProvider, $translateProvider) {
	// routes
	$routeProvider.when('/dashboard/:extra?',{	// "extra" is only used in dev to pass params on url
		templateUrl: 'partials/dashboard.html', 
		controller: 'DashboardCtrl'
	});
	$routeProvider.when('/entry/:entryid/:nonav?', {
		templateUrl: 'partials/entry.html', 
		controller: 'EntryCtrl'
	});
	$routeProvider.when('/export/:id/:ks', {
		templateUrl: 'partials/export.html',
		controller: 'ExportCtrl'
	});
	$routeProvider.when('/login', {
		template: '<script>window.parent.kmc.functions.expired();</script><div class="page container"><br/><p>invalid ks</p></div>' 
	});
	$routeProvider.otherwise({redirectTo: '/dashboard'});
	
	// translates
	$translateProvider.translations('en_US', en_US_trans);
	$translateProvider.useStaticFilesLoader({
		prefix: 'locale/',
		suffix: '.json'
	});
		 
	//$translateProvider.fallbackLanguage('en_US'); //TODO return this when we localize the app
	//var lang = window.lang ? window.lang : 'en_US';
	var lang = 'en_US';
	$translateProvider.preferredLanguage(lang);
}]);

function navigateToFlashAnalytics(subtabName) {
	$("#kcms",parent.document)[0].gotoPage({moduleName: "analytics",subtab: subtabName});
}

String.prototype.formatArgs = function() {
    var args = arguments;

    return this.replace(/\{(\d+)\}/g, function() {
        return args[arguments[1]];
    });
};


'use strict';

/* Controllers */

var analyticsControllers = angular.module('analyticsControllers', []);

/**
 * Dashboard Controller 
 */
analyticsControllers.controller('DashboardCtrl', ['$rootScope', '$scope', '$interval', '$timeout', '$translate', 'DashboardSvc',
    function($rootScope, $scope, $interval, $timeout, $translate, DashboardSvc) {
		
		$scope.Math = window.Math;
		
		/**
		 * entries currently on display
		 */
		var entries = [];
		
		/**
		 * number of entries in page
		 */
		var pageSize = DashboardSvc.pageSize;
		
		/**
		 * total number of pages
		 */
		var totalPages = 1;
		

		/**
		 * get data for the aggregates line
		 */
		var getAggregates = function getAggregates(liveOnly) {
			if (liveOnly) {
				DashboardSvc.getLiveAggregates().then (function(data) {
					/* 1 audience - 10 secs (now)
		 			 * 2 minutes viewed - 36 hours
		 			 * 3 buffertime, bitrate - 1 minute
		 			 * */
					var results = [
					           	{"title": "audience_inc_dvr", "value": parseInt(data[0].objects[0].audience, 10) + parseInt(data[0].objects[0].dvrAudience, 10), "tooltip": "agg_audience_tt"},
					        	{"title": "seconds_viewed", "value": data[1].objects[0].secondsViewed, "tooltip":"agg_secs_tt"},
					        	{"title": "buffertime", "value": data[2].objects[0].bufferTime, "tooltip":"agg_buffer_tt"},
					        	{"title": "bitrate", "value": data[2].objects[0].avgBitrate, "tooltip":"agg_bitrate_tt"}
					    ];

					$scope.aggregates = results;
					// reactivate tooltips
					$timeout(function() {$('.tooltip-wrap').tooltip();}, 0);
				});
			}
			else {
				DashboardSvc.getDeadAggregates().then (function(data) {
					var o;
					if (data.objects) o = data.objects[0];
					var results = [
					           	{"title" : "plays", 
					           		"value" : o ? o.plays : 0, 
					           		"tooltip" : "agg_plays_tt"},
					        	{"title": "seconds_viewed", "value": o ? o.secondsViewed : 0, "tooltip":"agg_secs_tt"},
					        	{"title": "buffertime", "value": o ? o.bufferTime : 0, "tooltip":"agg_buffer_tt"},
					        	{"title": "bitrate", "value": o ? o.avgBitrate : 0, "tooltip":"agg_bitrate_tt"}
						];

					$scope.aggregates = results;
					// reactivate tooltips
					$timeout(function() {$('.tooltip-wrap').tooltip();}, 0);
				});
			}
		};
		
		
		/**
		 * @param liveOnly	fetch KalturaLive currently live (true) or all live entries (false)
		 * @param pageNumber index of page to fetch
		 */
		var getEntries = function getEntries(liveOnly, pageNumber) {
			var result;
			if (liveOnly) {
				result = DashboardSvc.getLiveEntries(pageNumber); 
			}
			else {
				result = DashboardSvc.getAllEntries(pageNumber); 
			}
			 
			result.then(function(data) {
				$scope.entries = data.objects;
				totalPages = Math.ceil(data.totalCount/pageSize);

				updatePagingControl(pageNumber, totalPages);

			});
		};
		
		
		/**
		 * get entries data by page
		 * @param e
		 * @param oldPage
		 * @param newPage
		 */
		var doPaging = function doPaging(e,oldPage,newPage) {
			getEntries($scope.boardType == "liveOnly", newPage);
		};
		
		
		/**
		 * update paging control
		 * @param current	index of current page
		 * @param total		total number of pages
		 */
		var updatePagingControl = function updatePagingControl(current, total) {
			if (total < 1) total = 1; // it's only for display..
			var options = {
	                currentPage: current,
	                totalPages: total
	            };
	        $('#pagination').bootstrapPaginator(options);
		};
		
		
		/**
		 * trigger export to csv
		 */
		var export2csv = function export2csv() {
			var result = DashboardSvc.export2csv($scope.boardType == "liveOnly"); 
			result.then(function(data) {
				if (data.referenceJobId) {
					$translate('dashboard.export_success').then(function (msg) {
						bootbox.alert(msg.formatArgs([data.reportEmail]));
					});
				}
				else {
					$translate('dashboard.export_fail').then(function (msg) {
						bootbox.alert(msg);
					});
				}
			}, 
			function (error) {
				$translate('dashboard.export_fail').then(function (msg) {
					bootbox.alert(msg + "<br>" + error);
				});
			});
		};
		
		
		/**
		 * initial screen set up
		 */
		var screenSetup = function screenSetup() {
			// set report dates:
			var d = new Date();
			$scope.nowTime = d;
			d = new Date();
			d.setHours(d.getHours() - 36);
			$scope.reportStartTime = d;
			
			var options = {
					bootstrapMajorVersion: 3,
					onPageChanged: doPaging,
					shouldShowPage:function(type, page, current){
		                switch(type) {
		                    case "first":
		                    case "last":
		                        return false;
		                    default:
		                        return true;
		                }
		            },
		            alignment: 'center',
		            currentPage: 1,
		            totalPages: totalPages
		    };
	
		    $('#pagination').bootstrapPaginator(options);

			if ($rootScope.selectedBoard) {
				$scope.boardType = $rootScope.selectedBoard;
			}
			else {
				$scope.boardType = "all";
			}
			$scope.$watch("boardType", function(newValue, oldValue) {
				$rootScope.selectedBoard = newValue;
				$scope.entries = [];
				getAggregates(newValue == "liveOnly");
	    		getEntries(newValue == "liveOnly", 1);
			 });
			
			$scope.export2csv = export2csv;
			
			// set 30 secs update interval
			$scope.intervalPromise = $interval(function() {screenUpdate();}, 30000);
		};
		
		var screenUpdate = function screenUpdate() {
			
			$('.tooltip-wrap').tooltip('destroy');
			$('.panel-title').tooltip('destroy');
			
			var d = new Date();
			var t = d.getTime()/1000;
			
			$scope.nowTime = d;
			d = new Date();
			d.setHours(d.getHours() - 36);
			$scope.reportStartTime = d;
			getAggregates($scope.boardType == "liveOnly");
			var pages = $('#pagination').bootstrapPaginator('getPages');
			getEntries($scope.boardType == "liveOnly", pages.current);
		};
		
		
		$scope.$on('$destroy', function() {
			// Make sure that the interval is destroyed too
			if (angular.isDefined($scope.intervalPromise)) {
				$interval.cancel($scope.intervalPromise);
				$scope.intervalPromise = undefined;
			}
			// and tooltips
			$('.tooltip-wrap').tooltip('destroy');
			$('.panel-title').tooltip('destroy');
		});
		
		
		
		screenSetup();
		
    }]);


/**
 * General controller for the entry drill-down page
 */
analyticsControllers.controller('EntryCtrl', ['$scope', '$rootScope', '$routeParams', '$interval', '$timeout', '$translate', 'SessionInfo', 'EntrySvc',  
    function($scope, $rootScope, $routeParams, $interval, $timeout, $translate, SessionInfo, EntrySvc) {
		$scope.intervalPromise = null; 			// use this to hold update interval
		$scope.entryId = $routeParams.entryid;	// current entry
		$scope.pid = SessionInfo.pid;
		$scope.uiconfId = SessionInfo.uiconfid;
		$scope.playerEntryId = '';				// entry that should be shown in player (live / vod)
		$rootScope.nonav = $routeParams.nonav == 'nonav';
		

		/**
		 * get data for the aggregates line
		 * @param isLive is the entry currently broadcasting
		 */
		var getAggregates = function getAggregates(isLive) {
			if (isLive) {
				EntrySvc.getLiveAggregates($scope.entryId).then (function(data) {
					// data is MR
					var o = {'audience' : 0,
							'plays' : 0,
							'secondsViewed' : 0,
							'bufferTime' : 0,
							'avgBitrate' : 0
						};
					// audience - now
					if (data[0].objects && data[0].objects.length > 0) {
						o.audience = parseInt(data[0].objects[0].audience, 10) + parseInt(data[0].objects[0].dvrAudience, 10);
					}
					// seconds viewed - 36 hours
					if (data[1].objects && data[1].objects.length > 0) {
						o.secondsViewed = data[1].objects[0].secondsViewed;
					}
					// buffertime, bitrate - 1 minute
					if (data[2].objects && data[2].objects.length > 0) {
						o.bufferTime = data[2].objects[0].bufferTime;
						o.avgBitrate = data[2].objects[0].avgBitrate;
					}
					
					var results = [
					           	{"title": "audience", "value": o.audience, "tooltip": "agg_audience_tt"},
					        	{"title": "seconds_viewed", "value": o.secondsViewed, "tooltip":"agg_secs_tt"},
					        	{"title": "buffertime", "value": o.bufferTime, "tooltip":"agg_buffer_tt"},
					        	{"title": "bitrate", "value": o.avgBitrate, "tooltip":"agg_bitrate_tt"}
					        ];

					if ($scope.entry.dvrStatus) {
						results[0].title = "audience_inc_dvr";
					}
					
					$scope.aggregates = results;
					// reactivate tooltips
					$timeout(function() {$('.tooltip-wrap').tooltip();}, 0);
					
					getReferrers(true, 0); // totalplays value is ignored for live entries
				});
			}
			else {
				EntrySvc.getDeadAggregates($scope.entryId).then (function(data) {
					var o;
					if (data.objects && data.objects.length > 0) {
						o = data.objects[0];
					}
					else {
						// create empty dummy object
						o = {'audience' : 0,
							'plays' : 0,
							'secondsViewed' : 0,
							'bufferTime' : 0,
							'avgBitrate' : 0
						};
					}
					var results = [
					           	{"title" : "plays", "value" : o.plays,"tooltip" : "agg_plays_tt"},
					        	{"title": "seconds_viewed", "value": o.secondsViewed, "tooltip":"agg_secs_tt"},
					        	{"title": "buffertime", "value": o.bufferTime, "tooltip":"agg_buffer_tt"},
					        	{"title": "bitrate", "value": o.avgBitrate, "tooltip":"agg_bitrate_tt"}
					        ]; 
					
					$scope.aggregates = results;
					
					getReferrers(false, o.plays);
				});
			}
		};
		
		
		
		/**
		 * get data for the top referrals table
		 * @param totalPlays
		 * @param isLive
		 */
		var getReferrers = function getReferrers(isLive, totalPlays) {
			if (isLive) {
				// need to get the non-live entry stats and use the totalplays from there
				EntrySvc.getDeadAggregates($scope.entryId).then (function(data) {
					var o;
					if (data.objects && data.objects.length > 0) {
						o = data.objects[0];
					}
					else {
						// create empty dummy object
						o = {'audience' : 0,
							'plays' : 0,
							'secondsViewed' : 0,
							'bufferTime' : 0,
							'avgBitrate' : 0
						};
					}
					getReferrers(false, o.plays);
				});
			}
			else {
				EntrySvc.getReferrers($scope.entryId).then (function(data) {
					var objects;
					if (data.objects && data.objects.length > 0) {
						objects = data.objects;
					}
					else {
						objects = [];
					}
					var results = [];
					var o;
					for (var i = 0; i<objects.length; i++) {
						o = {
								'domain': objects[i].referrer, 
								'visits': objects[i].plays, 
								'percents' : objects[i].plays / totalPlays
							}; 
						results.push(o);
					}
					$scope.referals = results;
					// reactivate tooltips
					$timeout(function() {$('.tooltip-wrap').tooltip();}, 0);
				});
			}
		};
		
		
		/**
		 * get the entry in question
		 */
		var getEntry = function getEntry() {
			return EntrySvc.getEntry($scope.entryId).then(function(entry){
				$scope.entry = entry;
				if (entry.isLive) {
					// live session - show live entry in player
					$scope.playerEntryId = entry.id;
					// set 30 secs update interval
					$scope.intervalPromise = $interval(function() {screenUpdate();}, 30000);
				}
				else if (entry.recordedEntryId && entry.recordedEntryId != '') {
					// session ended, got recording - show recorded entry in player
					$scope.playerEntryId = entry.recordedEntryId;
				}
				else {
					// show "no recording" in player
					$scope.playerEntryId = -1;
				}
				// set report dates:
				var d = new Date();
				$scope.nowTime = d;
				$rootScope.$broadcast('setupScreen', Math.floor(d.getTime()/10000)*10);
				d = new Date();
				d.setHours(d.getHours() - 36);
				$scope.reportStartTime = d;
				getAggregates(entry.isLive);
				
			});
		};
		
		
		/**
		 * trigger export to csv based on live/dead and required kind
		 * @param reportKind audience/location/syndication
		 */
		var export2csv = function export2csv(reportKind) {
			var reportType;
			if ($scope.entry.isLive) {
				switch (reportKind) {
				case "audience":
					reportType = 12;
					break;
				case "location":
					reportType = 22;
					break;
				case "syndication":
					reportType = 32;
					break;
				}
			}
			else {
				switch (reportKind) {
				case "audience":
					reportType = 11;
					break;
				case "location":
					reportType = 21;
					break;
				case "syndication":
					reportType = 31;
					break;
				}
			}
			
			var result = EntrySvc.export2csv(reportType, $scope.entry.id); 
			result.then(function(data) {
				if (data.referenceJobId) { 
					$translate('dashboard.export_success').then(function (msg) {
						bootbox.alert(msg.formatArgs([data.reportEmail]));
					});
				}
				else {
					$translate('entry.export_fail').then(function (msg) {
						bootbox.alert(msg);
					});
				}
			}, 
			function (error) {
				$translate('entry.export_fail').then(function (msg) {
					bootbox.alert(msg + "<br>" + error);
				});
			});
		};
		
		
		
		var screenSetup = function screenSetup() {
			$scope.exportReportType = "default";
			$scope.$watch("exportReportType", function(newValue, oldValue) {
				if (newValue != "default") {
					export2csv(newValue);
				}
				$scope.exportReportType = "default";
			 });
			// report data:
			getEntry();
		};
		
		var screenUpdate = function screenUpdate() {
			$('.tooltip-wrap').tooltip('destroy');
			
			var d = new Date();
			var t = Math.floor(d.getTime()/10000) * 10;
			
			$scope.nowTime = d;
			d = new Date();
			d.setHours(d.getHours() - 36);
			$scope.reportStartTime = d;
			getAggregates($scope.entry.isLive);
			$rootScope.$broadcast('updateScreen', t);
		};
		
		
		$scope.$on('$destroy', function() {
			// Make sure that the interval is destroyed too
			if (angular.isDefined($scope.intervalPromise)) {
				$interval.cancel($scope.intervalPromise);
				$scope.intervalPromise = undefined;
			}
			// and tooltips
			$('.tooltip-wrap').tooltip('destroy');
		});
		
		screenSetup();
}]);

/**
 * General controller for report download page
 */
analyticsControllers.controller('ExportCtrl', ['$scope', '$rootScope', '$routeParams', '$translate', 'SessionInfo', '$location', 'ReportSvc', 'KApi',
	function($scope, $rootScope, $routeParams, $translate, SessionInfo, $location, ReportSvc, KApi ) {
		$rootScope.nonav = true;

		SessionInfo.setServiceUrl($location.protocol() + "://" + $location.host());

		KApi.setRedirectOnInvalidKS(false);

		var reportId = $routeParams.id;


		/**
		 * test the given KS
		 */
		var getSession = function getSession(ks) {
			return ReportSvc.getSession(ks).then(function(sessionInfo){
				if (sessionInfo.code == 'INVALID_KS') {
					$translate('export.Expired').then(function (msg) {
						$scope.message = msg;
					});
				}
				else {
					$translate('export.Report_Ready').then(function (msg) {
						$scope.message = msg;
					});
					$scope.downloadLink = getDownloadLink();
					$scope.downloadName = getDownloadName();
					$translate('export.Download').then(function (msg) {
						$scope.downloadMsg = msg;
					});
				}
			});
		};

		var getDownloadLink = function getDownloadLink() {
			var url = KApi.getApiUrl();
			url += "/service/liveReports/action/serveReport";
			url += "/ks/" + SessionInfo.ks;
			url += "/id/" + reportId;
			url += "/" + getDownloadName();
			return url;
		}

		var getDownloadName = function getDownloadName() {
			var results = reportId.match(/^[\d+]_[\d]+_Export_[a-zA-Z0-9]+_([\w\-]+.csv)$/);
			return results[1];
		}


		var screenSetup = function screenSetup() {
			$scope.downloadMsg = '';
			$translate('export.Verifying').then(function (msg) {
				$scope.message = msg;
			});
			getSession($routeParams.ks);
		};


		screenSetup();
	}]);

'use strict';

/* Controllers */

var analyticsControllers = angular.module('analyticsControllers'); // get, don't create!!

/**
 * controller for KDP on entry page
 */
analyticsControllers.controller('KPlayerController', ['$scope', '$attrs', '$interval', 'EntrySvc', 'SessionInfo',
    function($scope, $attrs, $interval, EntrySvc, SessionInfo) {
		var self = this;
		this.playerElement = null;
		this.eventCuePoints = new Array();
  		this.canSeek = false; // true if list broadcast cuepoints was executed

  		this.init = function init (element) {
  			self.playerElement = element;
  		};


		/**
		 * calculate correct player time based on firstBroadcast and start/stop broadcast cuepoints
		 * @param realTime	the required "real" time
		 * @param firstBroadcast	time of entry first broadcast start
		 * @return the time in seconds the player has to seek to get to the required "real" time
		 */
		this.getPlayerTime = function getPlayerTime(realTime, firstBroadcast) {
			var targetTime = realTime - firstBroadcast;
			var lastStopCp = null;
			// find start followed by stop and reduce their values
			for (var i = 0; i<this.eventCuePoints.length; i++) {
				// stop when not relevant anymore
				if (this.eventCuePoints[i].startTime > realTime) {
					break;
				}

				if (this.eventCuePoints[i].eventType == 2/*EventType.BROADCAST_STOP*/) {
					lastStopCp = this.eventCuePoints[i];
				}
				else if (this.eventCuePoints[i].eventType == 1/*EventType.BROADCAST_START*/) {
					if (lastStopCp != null) {
						var temp = (this.eventCuePoints[i].startTime - lastStopCp.startTime);
						targetTime -= temp;
						lastStopCp = null;
					}
				}
			}
			if (lastStopCp != null) {
				// time is between stop/start, need to remove (time - lastStop)
				targetTime -= (realTime - lastStopCp.startTime);
			}
			return targetTime;
		}


  		$scope.$on('gotoTime', function (event, time) {
			var kdp = angular.element('#kplayer')[0];
			if (self.canSeek && kdp) {
				// translate timestamp to entry time, go to correct time.
				var playerTime = self.getPlayerTime(time, $scope.entry.firstBroadcast);
				if (playerTime < $scope.entry.duration) {
					kdp.sendNotification("doSeek", playerTime);
				}
			}
  		});


  		$scope.$watch('playerEntryId', function( value ) {
  			function embedNow() {
  				kWidget.embed({
  					"targetId": "kplayer",
  					"wid": "_" + $scope.pid,
  					"uiconf_id": $scope.uiconfId,
  					"entry_id": value,
  					"flashvars": {
						"ks": SessionInfo.ks,
  						"streamerType": "auto"
  					}
  				});
  			};
  			if (value) {
  				if (value != -1) {
					// list broadcast cuepoints
					EntrySvc.listEventCuepoints($scope.entry.id).then(function(data) {
						// data is eventCuepointListResponse
						self.eventCuePoints = data.objects;
						self.canSeek = true;
					});
					// embed
  					if (window.playerLibLoaded) {
			  			embedNow();
  					}
  					else {
  						// setTimeout until loaded
  						$scope.playerIntervalPromise = $interval(function() {
  							if (window.playerLibLoaded) {
  								$interval.cancel($scope.playerIntervalPromise);
  								$scope.playerIntervalPromise = undefined;
  								embedNow();
  							}
  						}, 500);
  					}
  				} else {
  					self.playerElement.html('<h3>Live Session Was Not Recorded</h3>');
  				}
  				$scope.playerEntryId = null;
	  		}
  		});

  		$scope.$on('$destroy', function() {
			// Make sure that the interval is destroyed too
			if (angular.isDefined($scope.playerIntervalPromise)) {
				$interval.cancel($scope.playerIntervalPromise);
				$scope.playerIntervalPromise = undefined;
			}
		});
}]);


'use strict';


/**
 * controller for (rickshaw) graph on entry page
 */
analyticsControllers.controller('RGraphController', ['$scope', '$attrs', 'EntrySvc', 
    function($scope, $attrs, EntrySvc) {
		var self = this;
		var graphElement = null; 	// HTML element showing the graph
		var graph = null;			// graph JS object
		var series = null;			// data container
		var dvrEnabledForEntry = false;
		
		this.init = function init (element) {
			graphElement = element;
			var d = new Date();
			var t = d.getTime()/1000;
			series = [{
					color : '#8ecc00',
					data : [ {x:t, y:0} ],
					name : "Audience"
				},
				{
					color : '#ff8a00',
					data : [ {x:t,y:0} ],
					name : "DVR"
				}];

			graph = createGraph(series, element);
		};
		

		var graphClickHandler = function graphClickHandler(time) {
			if (!$scope.entry.isLive) {
				// click - only for recorded entries that are not currently live
				$scope.$emit('gotoTime', time);
			}
		};
		
		/**
		 * create graph and its parts
		 * @param series
		 * @param element
		 * @return rickshaw graph
		 */
		var createGraph = function createGraph(series, element) {
			var graph = new Rickshaw.Graph({
				element : element[0].children[0],
				width : element.width(),
				height : element.height() - 20,
				renderer : 'line',
				interpolation: 'linear',
				series : series
			});
			graph.render();

			var preview = new Rickshaw.Graph.RangeSlider({
				graph : graph,
				element : element[0].children[1]
			});

			var xAxis = new Rickshaw.Graph.Axis.Time({
				graph : graph,
				ticksTreatment : 'glow',
				timeFixture : new KTime_Local()
			});
			xAxis.render();

			var yAxis = new Rickshaw.Graph.Axis.Y({
				graph : graph,
				tickFormat : Rickshaw.Fixtures.Number.formatKMBT,
				ticksTreatment : 'glow'
			});
			yAxis.render();
			
			var hoverDetail = new KHoverDetail( {
			    graph: graph,
			    formatter: function(series, x, y, formattedXValue, formattedYValue, point) {
			    	return formattedXValue + '<br>' + series.name + ': ' + y ;
			    },
				onClick : graphClickHandler
			} );
			
			return graph;
		};
		
		
		/**
		 * @param str	info string
		 * @return Object {audience: [{x, y}, ..], dvr: [{x, y}, ..]}
		 */
		var parseData = function parseData(str) {
			var os = str.split(';');
			var audienceObjects = new Array();
			var dvrObjects = new Array();
			os.forEach(function (sLine) {
				if (sLine) {
					var vals = sLine.split(',');
					audienceObjects.push({'x':parseInt(vals[0], 10), 'timestamp':parseInt(vals[0], 10), 'y':parseInt(vals[1], 10)});
					dvrObjects.push({'x':parseInt(vals[0], 10), 'timestamp':parseInt(vals[0], 10), 'y':parseInt(vals[2], 10)});
				}
			});
			return {"audience" : audienceObjects, "dvr" : dvrObjects };
		};


		var balanceBoth = function balanceBoth(data, fromDate, toDate, fillAll) {
			var audience = balanceData (data.audience, fromDate, toDate, fillAll);
			var dvr = balanceData(data.dvr, fromDate, toDate, fillAll);
			return {"audience":audience, "dvr":dvr};
		}


		/**
		 * add 0 points where no data received
		 * for live - all the way
		 * for dead - after first point, before last point
		 * @param data 		objects array with "holes"
		 * @param fromDate	timestamp, seconds
		 * @param toDate	timestamp, seconds
		 * @param fillAll	boolean, should data outside existing range be filled
		 * @return array without "holes"
		 */
		var balanceData = function balanceData(data, fromDate, toDate, fillAll) {
			var firstPoint = Math.floor(fromDate/10)*10;	// init like this for when no data
			var lastPoint = firstPoint;
			var curx, nextx, i = 1;
			if (data.length) {
				firstPoint = data[0].x;
				lastPoint = data[data.length-1].x;
			}

			// add points between lastPoint and firstPoint
			curx = firstPoint + 10;
			while (curx < lastPoint) {
				nextx = data[i].x;
				if (curx < nextx) {
					// need to add point here
					data.splice(i, 0, {'x':curx, 'timestamp':curx, 'y':0});
				}
				curx += 10;
				i++;
			}
			
			if (fillAll) {
				// add points between firstPoint and fromDate 
				curx = firstPoint - 10;
				while (curx >= fromDate) {
					data.unshift({'x':curx, 'timestamp':curx, 'y':0});
					curx -= 10;
				}

				// add points after lastPoint
				curx = lastPoint + 10;
				while (curx <= toDate) {
					data.push({'x':curx, 'timestamp':curx, 'y':0});
					curx += 10;
				}
			}
			return data;
		};
		
		/**
		 * get graph data for the last 36 hrs 
		 * @param end of 36 hrs term (timestamp sec)
		 */
		var getGraph36Hrs = function getGraph36Hrs(toDate) {
			toDate = toDate - 60;
			var fromDate = toDate - 12960; // 60 sec per minute * 60 minutes per hour * 36 hrs
			EntrySvc.getGraph($scope.entryId, -129660, -60).then(function(data) {
				if (data[0] && graph != null) {
					// parse string into objects
					var objects = parseData(data[0].data);
					// add 0 points where no data received
					objects = balanceBoth(objects, fromDate, toDate, $scope.entry.isLive);
					if (!$scope.entry.isLive) {
						var firstBroadcast = parseInt($scope.entry.firstBroadcast, 10);
						// trim data edges:
						if (!isNaN(firstBroadcast)) {	// non-kaltura don't have firstBroadcast
							for (var i = 0; i < objects.audience.length; i++) {
								if (objects.audience[i].timestamp >= firstBroadcast) {
									break;
								}
							}
						}
						for (var j = objects.audience.length - 1; j>=0; j--) {
							if (objects.audience[j].value != 0) {
								j++;
								break;
							}
						}
						objects.audience = objects.audience.slice(i, j);
						objects.dvr = objects.dvr.slice(i, j);
						if (objects.audience.length) {
							$scope.$emit('TimeBoundsSet', objects.audience[0].timestamp, objects.audience[objects.audience.length - 1].timestamp);
						}
					}
					resetGraphContent(objects);
				};
			});
		};
		
		
		/**
		 * get graph data for the last 30 secs 
		 * @param endTime (timestamp sec) get graph data for 30 secs up to this time
		 */
		var getGraph30Secs = function getGraph30Secs(endTime) {
			var toDate = -60;	//endTime;
			var fromDate = -122;
			EntrySvc.getGraph($scope.entryId, fromDate, toDate).then(function(data) {
				var objects = parseData(data[0].data);
				objects = balanceBoth(objects, endTime-122, endTime-60, $scope.entry.isLive);
				if (graph != null) {
					updateGraphContent(objects);
				}
			});
		};
		
		
		/**
		 * remove all previous data and set new 
		 * @param value {audience:array, dvr:array}
		 */
		var resetGraphContent = function resetGraphContent(value) {
			// empty audience
			var ar = series[0].data;
			while (ar.length > 0) {
				ar.pop();
			}

			// fill new
			for ( var i = 0; i < value.audience.length; i++) {
				series[0].data.push(value.audience[i]);
			}
			if (dvrEnabledForEntry) {
				// empty dvr
				ar = series[1].data;
				while (ar.length > 0) {
					ar.pop();
				}
				// fill new
				for (var i = 0; i < value.dvr.length; i++) {
					series[1].data.push(value.dvr[i]);
				}
			}
			graph.update();
		};


		/**
		 * update both graph kines with new content
		 * @param value {audience:array, dvr:array} points to add to the graph
		 */
		var updateGraphContent = function updateGraphContent(value) {
			updateSingleGraphContent(series[0].data, value.audience);
			if (dvrEnabledForEntry) {
				updateSingleGraphContent(series[1].data, value.dvr);
			}
			graph.update();
		}


		/**
		 * add new data and purge oldest so we keep only 36 hrs
		 * @param graphData:array points already in the graph
		 * @param value:array points to add to the graph
		 */
		var updateSingleGraphContent = function updateSingleGraphContent(graphData, value) {
			var lastGraphDataX = graphData[graphData.length-1].x;
			// first see if any existing values need to be updated
			for (var i = 0; i<value.length; i++) {
				var valX = value[i].x;
				if (valX <= lastGraphDataX) {
					// this x value is already in the graph
					for (var j = graphData.length-1; j>=0; j--) {
						if (graphData[j].x == valX) {
							if ( value[i].y != 0) {
								graphData[j].y = value[i].y;
							}
							break;
						}
						else if (graphData[j].x < valX) {
							// j will only become smaller
							break;
						}
					}
				}
				else {
					// valX is out of graphData bounds, will be so for any larger i
					break;
				}
			}
			
			// then shift/push for new ones
			while(i < value.length) {
				if (graphData.length >= 12960)
					graphData.shift();
				graphData.push(value[i]);
				i++;
			}
		};
		
		
		/**
		 * event handler for main screen setup event
		 * @param event
		 * @param time (timestamp sec)
		 */
		var setupScreenHandler = function setupScreenHandler(event, time) {
			dvrEnabledForEntry = $scope.entry.dvrStatus == 1 // KalturaDVRStatus.ENABLED
			if (!dvrEnabledForEntry) {
				series.pop();
			}
			getGraph36Hrs(time);
		};
		
		
		/**
		 * event handler for main screen update interval
		 * @param event
		 * @param time (timestamp sec)
		 */
		var updateScreenHandler = function updateScreenHandler(event, time) {
			getGraph30Secs(time);
		};
	
		$scope.$on('setupScreen', setupScreenHandler);
		$scope.$on('updateScreen', updateScreenHandler);
}]);
'use strict';


/**
 * controller for map on entry page
 */
analyticsControllers.controller('OLMapController', ['$scope', '$attrs',  '$location', 'EntrySvc', 'SessionInfo',
    function($scope, $attrs, $location, EntrySvc, SessionInfo) {
		var self = this;
		this.mapElement = null;
		this.slider = null;
		this.sliderTicks = null;
		this.map = null;
		this.citiesLayer = null;
		this.countriesLayer = null;
		this.dvrEnabledForEntry = false;
		this.color1 = '8ecc00';
		this.color2 = 'ff8a00';
		this.color3 = '4e4e4e';
		this.lastRequestedTime = null;

		this.init = function init (element) {
			self.mapElement = element;
			
			// create map
			self.map = new OpenLayers.Map('map', {theme: null});
	
			// create OSM layer
			var osm = new OpenLayers.Layer.OSM('OpenStreetMap', [], {numZoomLevels:SessionInfo.map_zoom_levels});
			// add target so we won't try to open in frame
			osm.attribution = "&copy; <a href='http://www.openstreetmap.org/copyright' target='_blank'>OpenStreetMap</a> contributors";
			if (SessionInfo.map_urls) {
				osm.url = self.processMapUrls(SessionInfo.map_urls);
			}
			self.map.addLayer(osm);
			self.map.zoomToMaxExtent();
			self.map.events.register('zoomend', this, function (event) {
				if (!self.citiesLayer) return; // if no layers no need to toggle.
				
		        var zLevel = self.map.getZoom();     
		        if( zLevel < 4)
		        {
		        	// show countries
		        	self.citiesLayer.setVisibility(false);
		            self.countriesLayer.setVisibility(true);
		        }
		        else {
		        	// show cities
		        	self.citiesLayer.setVisibility(true);
		            self.countriesLayer.setVisibility(false);
		        }
		    });
			
			// create slider
			var d = new Date();
			var t = Math.floor(d.getTime() / 1000);
			self.slider = angular.element('#mapslider');
			self.slider.slider({
				max: t, 
				min: t - 129600, // 36 hrs
				value: t, 
				step: 10,
				change: self.sliderChangeHandler,
				slide: function (event, ui) {
					d = new Date(ui.value*1000);
					angular.element('#maptip .tooltip-inner').text(self.formatTime(d));
					angular.element('#maptip').css('left', $(ui.handle).css('left'));
					angular.element('#maptip').removeClass('hidden');
			    }
			});

			angular.element('#mapslider .ui-slider-handle').mouseleave(function() {
				angular.element('#maptip').addClass('hidden');
				angular.element('#maptip .tooltip-inner').text("");
				angular.element('#maptip').css('left', $(this).css('left'));
			});
		
			// create ticks
			self.sliderTicks = angular.element('#sliderticks');
			self.createSliderTicks(t-12960, t);
			
		};


		$scope.$on('gotoTime', function (event, time) {
			// show required time data on map
			self.slider.slider("option", "value", time);
		});

		/**
		 * make sure the urls start with either protocol or '//'
		 * @param urls Array
		 * @return urls array with protocol
		 */
		this.processMapUrls = function processMapUrls(urls) {
			var result = [];
			for (var i = 0; i<urls.length; i++) {
				if (urls[i].indexOf('http') == 0 && urls[i].indexOf('//') == 0) {
					result.push(urls[i] + "/${z}/${x}/${y}.png");
				}
				else {
					result.push('//' + urls[i] + "/${z}/${x}/${y}.png");
				}
			}
			return result;
		}

		/**
		 * event handler for the slider drag
		 */
		this.sliderChangeHandler = function sliderChangeHandler(event, ui) {
			angular.element('#maptip').addClass('hidden');
			angular.element('#maptip .tooltip-inner').text("");
			self.getMapData(ui.value);
		};
		
		
		/**
		 * @param min, max - timestamp (seconds)
		 */
		this.createSliderTicks = function createSliderTicks(min, max) {
			// remove existing ticks
			self.sliderTicks.html('');
			// create new ticks
			var step, left, label, range = max-min, cnt = 6;
			for (var i = 0; i<cnt; i++) {
				step = i / cnt;
				label = min + range * step;
				var d = new Date(Math.floor(label*1000));
				label = self.formatTime(d);
				left = step * 100;
				self.createSliderTick(left + '%', label);
			}

		};
		
		
		this.createSliderTick = function createSliderTick(left, txt) {
			var element = document.createElement('div');
			element.style.left = left;
			element.classList.add('slidertick');
			var title = document.createElement('div');
			title.classList.add('title');
			title.innerHTML = txt;
			element.appendChild(title);
			self.sliderTicks[0].appendChild(element);
		};
		
		this.formatTime = function formatTime(d) {
			return d.toString().match(/(\d+:\d+:\d+)/)[1];
		};
		
		
		/**
		 * create a style map for the dots
		 * @param min the smallest data point value
		 * @param max the largest data point value
		 */
		this.createStyleMap = function createStyleMap(min, max) {
			var sRadius = 4;
			var lRadius = 10;
			var blue = this.color1;
			var orange = this.color2;
			// style
			var style = new OpenLayers.Style({
				pointRadius: "${radius}",
				fillColor: "${fillColor}",
				fillOpacity: 0.8,
				strokeColor: '#' + this.color3,
				strokeWidth: 1,
				strokeOpacity: 0.8,
				title : "${tooltip}"
			},
			{
				context: {
					radius: function(feature) {
						// data point size normalization
						if (max == min) return lRadius;
						return lRadius - ((max - feature.attributes.data) * (lRadius - sRadius) / (max - min));
					},
					tooltip: function(feature) {
						var str = feature.attributes.text+ ": " + feature.attributes.audience;
						if (self.dvrEnabledForEntry) {
							str += "\nDVR: " + feature.attributes.dvr;
						}
						return str;
					},
					fillColor:function(feature) {
						// data point color normalization
						var ro = parseInt(orange.substring(0,2), 16);
						var rb = parseInt(blue.substring(0,2), 16);
						var r = ro + (feature.attributes.audience / (feature.attributes.dvr + feature.attributes.audience)) * (rb - ro);
						r = Math.round(r);
						r = r.toString(16);
						if (r.length === 1) r = "0" + r;

						var go = parseInt(orange.substring(2,4), 16);
						var gb = parseInt(blue.substring(2,4), 16);
						var g = go + (feature.attributes.audience / (feature.attributes.dvr + feature.attributes.audience)) * (gb - go);
						g = Math.round(g);
						g = g.toString(16);
						if (g.length === 1) g = "0" + g;

						var bo = parseInt(orange.substring(4, 6), 16);
						var bb = parseInt(blue.substring(4, 6), 16);
						var b = bo + (feature.attributes.audience / (feature.attributes.dvr + feature.attributes.audience)) * (bb - bo);
						b = Math.round(b);
						b = b.toString(16);
						if (b.length === 1) b = "0" + b;

						return "#" + r + g + b;
					}
				}
			}
			);
			
			// create a styleMap with a custom default symbolizer
			var styleMap = new OpenLayers.StyleMap({
				"default": style,
				"select": {
					fillColor: '#' + this.color1,
					strokeColor: '#' + this.color3
				}
			});
			
			return styleMap;
		};
		
		
		/**
		 * get data to display on map
		 * @param time unix timestamp (seconds). if null, current time is used.
		 */
		this.getMapData = function getMapData(time) {
			self.lastRequestedTime = time;
			EntrySvc.getMap($scope.entryId, time).then(function(data) {
				if (!data.objects || data.objects[0].timestamp == self.lastRequestedTime.toString()) {
					self.displayData(data.objects);
				}
			});
			
		};
		
		
		/**
		 * recreate data layers on map
		 * @param value array of KalturaGeoTimeLiveStats
		 */
		this.displayData = function displayData(value) {
			// remove existing layers
			if (self.citiesLayer) {
				self.map.removeLayer(self.citiesLayer);
				self.citiesLayer = null;
			}
			if (self.countriesLayer) {
				self.map.removeLayer(self.countriesLayer);
				self.countriesLayer = null;
			}
			if (value) { 
				// process data to create new layers
				var countriesData = {};
				var features = new Array();
				var point;
				var min = 0;
				var max = 0;
				for ( var i = 0; i < value.length; i++) {
					var val = parseInt(value[i].audience, 10) + parseInt(value[i].dvrAudience, 10); // convert string to int
					if (val == 0) continue; // leave out points where audience is zero - we got them because they have plays)
					// accumulate data for country-level layer
					if (!countriesData[value[i].country.name]) { 
						// init - keep whole value for lat/long
						countriesData[value[i].country.name] = value[i];
						countriesData[value[i].country.name]['audience'] = parseInt(value[i].audience, 10);
						countriesData[value[i].country.name]['dvrAudience'] = parseInt(value[i].dvrAudience, 10);
					}
					else {
						// sum audience
						countriesData[value[i].country.name]['audience'] += parseInt(value[i].audience, 10);
						countriesData[value[i].country.name]['dvrAudience'] += parseInt(value[i].dvrAudience, 10);
					}
					point = new OpenLayers.Geometry.Point(value[i].city.longitude, value[i].city.latitude).transform('EPSG:4326', 'EPSG:3857');
					features.push(new OpenLayers.Feature.Vector(
							point, 
							{
								"audience" : value[i].audience,
								"dvr" : value[i].dvrAudience,
								"data" : val,
								"text" : value[i].city.name
							}
							));
					// update cities min-max
					if (min == 0 || val < min) {
						min = val;
					}
					if (val > max) {
						max = val;
					}
				}
				
				// create cities layer
				var layer = self.citiesLayer = new OpenLayers.Layer.Vector('Cities', {
					"projection": "EPSG:3857",
					"visibility" : self.map.zoom > 3,
					"styleMap" : self.createStyleMap(min, max)
				});
				layer.addFeatures(features);
				self.map.addLayer(layer);
				
				// create countries layer
				min = max = 0;
				features = new Array();
				for (var key in countriesData) {
					var val = countriesData[key].audience + countriesData[key].dvrAudience;
					point = new OpenLayers.Geometry.Point(countriesData[key].country.longitude, countriesData[key].country.latitude).transform('EPSG:4326', 'EPSG:3857');
					features.push(new OpenLayers.Feature.Vector(
							point, 
							{
								"audience" : countriesData[key].audience,
								"dvr" : countriesData[key].dvrAudience,
								"data" : val,
								"text" : countriesData[key].country.name
							}
							));
					// update countries min-max
					if (min == 0 || val < min) {
						min = val;
					}
					if (val > max) {
						max = val;
					}
				}
				
				// create countries layer
				layer = self.countriesLayer = new OpenLayers.Layer.Vector('Countries', {
					"projection": "EPSG:3857",
					"visibility" : self.map.zoom < 4,
					"styleMap" : self.createStyleMap(min, max)
				});
				layer.addFeatures(features);
				self.map.addLayer(layer);
				
				layer.refresh();
			}
		};
		
		
		this.adjustSlider = function adjustSlider(oldmax, newmax, val) {
			var n = newmax - oldmax;
			var min = self.slider.slider("option", "min");
			self.slider.slider("option", "max", newmax);
			self.slider.slider("option", "min", min + n);
			if (val) {
				self.slider.slider("option", "value", val);
			}
			self.createSliderTicks(min+n, newmax);
		};
		
		
		/**
		 * event handler for main screen update interval
		 * @param event
		 * @param timestamp (seconds)
		 */
		this.updateScreenHandler = function updateScreenHandler(event, time) {
			time -= 60; // we only have data about 60 seconds back, so we adjust what we got  
			var val = self.slider.slider("option", "value"); // current slider value 
			var max = self.slider.slider("option", "max"); // max slider value
			if (val == max) {
				// we are at the right edge, auto update
				//self.getMapData(time); // adjusting the slider will also trigger the update
				// update scrollbar and handle (keep handle on right edge)
				self.adjustSlider(max, time, time);
			}
			else {
				// update range 
				self.adjustSlider(max, time);
			}
			self.dvrEnabledForEntry = $scope.entry.dvrStatus == 1 // KalturaDVRStatus.ENABLED
		};
		
		this.timeBoundsSetHandler = function timeBoundsSetHandler(event, start, end) {
			start = parseInt(start, 10);
			end = parseInt(end, 10);
			var val = self.slider.slider("option", "value"); // current slider value 
			var max = self.slider.slider("option", "max"); // max slider value
			if (val == max) {
				// we are at the right edge, stay there
				self.slider.slider("option", "max", end);
				self.slider.slider("option", "min", start);
				self.slider.slider("option", "value", end);
			}
			else {
				var updateVal = false;
				if (val < start) {
					val = start;
					updateVal = true; 
				}
				if (val > end) {
					val = end;
					updateVal = true;
				}
				self.slider.slider("option", "max", end);
				self.slider.slider("option", "min", start);
				if (updateVal) {
					self.slider.slider("option", "value", val);
				}
			}
			self.createSliderTicks(start, end);
		};
		
		$scope.$on('setupScreen', self.updateScreenHandler);
		$scope.$on('updateScreen', self.updateScreenHandler);
		$scope.$on('TimeBoundsSet', self.timeBoundsSetHandler);
		
}]);


'use strict';

/* Directives */

var analyticsDirectives = angular.module('analyticsDirectives', []);


analyticsDirectives.directive('kplayer', function() {
	return {
		restrict : 'A',
		controller: 'KPlayerController',
		replace : false,
		template: '<div id="kplayer" class="full-width full-height"></div>',
		link: function($scope, element, attrs, KPlayerController) {
			KPlayerController.init(element);
		}
	};
});

analyticsDirectives.directive('rgraph', function() {
	return {
		restrict : 'A',
		controller: 'RGraphController',
		template : '<div id="graph"></div><div id="preview"></div>',
		replace : false,
		link : function(scope, element, attrs, RGraphController) {
			RGraphController.init(element);
			
		}
	};
});


analyticsDirectives.directive('olmap', function() {
	return {
		restrict : 'A',
		controller : 'OLMapController',
		template : '<div id="map"></div><div id="mapctrls"><div id="sliderticks"></div><div id="maptip" class="hidden tooltip top slider-tip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div><div id="mapslider"></div></div>',
		replace : false,
		link : function(scope, element, attrs, OLMapController) {
			OLMapController.init(element);
		}
	};
});

analyticsDirectives.directive('ellipsis', ['$timeout', function($timeout) {
	return {
		restrict : 'A',
		link : function(scope, element, attrs) {
			var func = function() {
				if (element[0].offsetWidth < element[0].scrollWidth) {
					element.attr('title', element[0].innerHTML);
					element.addClass('ellipsis');
					element.tooltip();
				} 
			};
			$timeout(func, 0);
		}
	};
}]);

analyticsDirectives.directive('fitfontsize', function() {
	return {
		restrict : 'A',
		link : function(scope, element, attrs) {
			var update = function(value) {
				element.text(value);
				var fontSize = element.css('font-size');
				fontSize = fontSize.substr(0, fontSize.length - 2);
				var maxWidth = 200;
				var textWidth;
				do {
					element.css('font-size', fontSize + "px");
					textWidth = element.width();
					fontSize -= 1;
				} while ((textWidth > maxWidth) && fontSize > 3);
			}
			attrs.$observe('fitfontsize', function(value){
				update(value);
			});
		}
	}
});
'use strict';

/* Filters */


var analyticsFilters = angular.module('analyticsFilters', []);

/**
 * formats a time string without using Flash's Date object
 * @param secs
 * @param showHours		if hours is more than 0, show it
 * @param showSeconds	show seconds (even if 0)
 * @param forceHours	show hours even if 0
 * @return given value, formatted as {HH}:MM:{SS }
 */
function formatTime(secs, showHours, showSeconds, forceHours) {
	var h = Math.floor(secs / 3600); // 60 * 60 = 3600
	var sh = h * 3600;	// hours in seconds
	var m = Math.floor((secs - sh) / 60);
	var sm = m * 60;	// minutes in seconds
	var s = secs - sh - sm;
	
	var result = '';
	if (h>0 || m>0) {
		if ((showHours && h>0) || forceHours) {
			result += addZero(h) + ':'; 
		}
		result += addZero(m);
		if (showSeconds) {
			result += ':' + addZero(s);
		}
	}
	else {
		// only seconds, maybe
		if (showSeconds) {
			result = addZero(s);
		}
		else {
			return '00';
		}
	}
	return result;
};

function addZero(n) {
	return (n<10 ? '0' : '') + n;
};


analyticsFilters.filter('formatAgg', [ '$filter', function($filter) {
	var formatAgg = function formatAgg(agg) {
		var result = '';
		switch (agg.title) {
		case 'audience':
		case 'audience_inc_dvr':
		case 'plays':
			result = $filter('number')(agg.value, 0);
			break;
		case 'seconds_viewed':
			result = $filter('number')(agg.value/60, 0); // actually returns minutes
			break;
		case 'buffertime':
			result = $filter('number')(agg.value, 2);
			if (result.indexOf('.') > 4) {
				// if we have 4 digits number, we only want a single digit after the dec point
				result = $filter('number')(agg.value, 1);
			}
			break;
		case 'bitrate':
			result = $filter('number')(agg.value, 2);
			if (result.indexOf('.') > 4) {
				// if we have 4 digits number, we only want a single digit after the dec point
				result = $filter('number')(agg.value, 1);
			}
			break;
		}
		return result;
	}; 
	
	return formatAgg;
}]);

analyticsFilters.filter('time', [function() {
	var time = function time(val) {
		return formatTime(val, false, true);
	}; 
	
	return time;
}]);

analyticsFilters.filter('percents', [function() {
	// val is expected to be 0-1, return value has 2 digits after dec. (65.44)
	var percents = function percents(val) {
		return Math.floor(val * 10000) / 100;
	}; 
	
	return percents;
}]);

analyticsFilters.filter('avgBitrate', [function() {
	var avgBitrate = function avgBitrate(val) {
		return parseFloat(val);
	}; 
	
	return avgBitrate;
}]);

'use strict';

/* Services */

var analyticsServices = angular.module('analyticsServices', [ 'ngResource' ]);


analyticsServices.factory('SessionInfo',
		['$location',
		 	function SessionInfoFactory($location) {
		 		var sessionInfo = {};
		 		sessionInfo.ks = '';
		 		sessionInfo.pid = '';
		 		sessionInfo.uiconfid = '';
				sessionInfo.map_urls = [
					      'a.tile.openstreetmap.org/${z}/${x}/${y}.png',
					      'b.tile.openstreetmap.org/${z}/${x}/${y}.png',
					      'c.tile.openstreetmap.org/${z}/${x}/${y}.png'
					      ];
				sessionInfo.map_zoom_levels = 10;
		 		
		 		sessionInfo.setKs = function setKs(value) {
		 			sessionInfo.ks = value;
		 		};
		 		sessionInfo.setPid = function setPid(value) {
		 			sessionInfo.pid = value;
		 		};
		 		sessionInfo.setUiconfId = function setUiconfId(value) {
		 			sessionInfo.uiconfid = value;
		 		};
				sessionInfo.setServiceUrl = function setServiceUrl(value) {
		 			sessionInfo.service_url = value;
		 		};
				sessionInfo.setMapUrls = function setMapUrls(value) {
		 			sessionInfo.map_urls = value;
		 		};
				sessionInfo.setMapZoomLevels = function setZoomLevels(value) {
		 			sessionInfo.map_zoom_levels = value;
		 		};


		 		try {
	                var kmc = window.parent.kmc;
	                if (kmc && kmc.vars) {
	                    if (kmc.vars.ks)
	                        sessionInfo.ks = kmc.vars.ks;
	                    if (kmc.vars.partner_id)
	                    	sessionInfo.pid = kmc.vars.partner_id;
	                    if (kmc.vars.service_url) 
	                    	sessionInfo.service_url = kmc.vars.service_url;
	                    if (kmc.vars.liveanalytics) {
							sessionInfo.uiconfid = kmc.vars.liveanalytics.player_id;
							if (kmc.vars.liveanalytics.map_urls) {
								sessionInfo.map_urls = kmc.vars.liveanalytics.map_urls;
							}
							if (kmc.vars.liveanalytics.map_zoom_levels) {
								var n = parseInt(kmc.vars.liveanalytics.map_zoom_levels);
								if (n > 0) {
									sessionInfo.map_zoom_levels = n;
								}
							}
						}


	                }
	            } catch (e) {
	                console.log('Could not locate parent.kmc: ' + e);
	            }
	            
	       /*     if (!sessionInfo.ks) { //navigate to login
	                $location.path("/login");
	            } */
	            
		 		return sessionInfo;
		 	} 
	 	]);

		
		
analyticsServices.factory('KApi',
		['$http', '$q', '$location', 'SessionInfo',
		 	function KApiFactory ($http, $q, $location, SessionInfo) {
		 		var KApi = {};

				KApi.redirectToLoginOnInvalidKS = true;

				KApi.setRedirectOnInvalidKS = function setRedirectOnInvalidKS(value) {
					KApi.redirectToLoginOnInvalidKS = value;
				}
		 		
		 		KApi.IE = (!!window.ActiveXObject && +(/msie\s(\d+)/i.exec(navigator.userAgent)[1])) || NaN;


				KApi.getApiUrl = function getApiUrl() {
					return SessionInfo.service_url + "/api_v3/index.php";
				}


				/**
		 		 * @param request 	request params
		 		 * @returns	promise object
		 		 */
		 		KApi.doRequest = function doRequest (request) {
		 			// Creating a deferred object
		            var deferred = $q.defer();
			 		// add required params
		            request.ks = SessionInfo.ks;
		            var method = "post";
			 		var sParams;
			 		var params;
			 		if (KApi.IE < 10) {
	                    request['callback'] = 'JSON_CALLBACK';
	                    request['format'] = '9';
	                    params = request;
	                    method = 'jsonp';
	                }
			 		else {
			 			params = {'format' : '1'};
			 			sParams = this.serializeParams(request);
			 		}
			 		
			 		$http({
			 			data: sParams,
			 			url: SessionInfo.service_url + "/api_v3/index.php",
				 		method: method,
			 			params: params,
			 			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			 		}).success(function (data, status) {
						if (KApi.redirectToLoginOnInvalidKS) {
							if (data.objectType === "KalturaAPIException") {
								if (data.code == "INVALID_KS") {
									console.log(data);
									$location.path("/login");
								}
								else {
									deferred.reject(data.message);
								}
							}
							else {
								deferred.resolve(data);
							}
						}
						else {
							deferred.resolve(data);
						}
			 		}).error(function(data, status) {
			 			console.log(data);
			 			$location.path("/login");
			 			//deferred.reject(data.message);
			 		});
			 		
			 		// Returning the promise object
		            return deferred.promise;
		 		};
		 		
		 		
		 		/**
		 		 * format params as &key1=val1&key2=val2
		 		 * @param params
		 		 * @returns {String}
		 		 */
		 		KApi.serializeParams = function serializeParams(params) {
		 			var s = '';
		 			for (var key in params) {
		 				s += '&' + key + '=' + params[key];
		 			}
		 			return s;
		 		};


				KApi.getExportHandlerUrl = function getExportHandlerUrl() {
					var url = $location.absUrl();
					url = url.substring(0, url.indexOf('#/'));
					url += "#/export/[id]/[ks]";
					return url;
				}
		 		
		 		return KApi;
		 	}
		]);

analyticsServices.factory('DashboardSvc',
		['KApi', '$resource', '$q',  
		 	function DashboardSvcFactory(KApi, $resource, $q) {
		 		var DashboardSvc = {};

				DashboardSvc.HOURS_AGO_IN_SEC = -129600;
		 		
		 		/**
		 		 * always use 10 items in page
		 		 */ 
		 		DashboardSvc.pageSize = '10';
		 		
		 		/**
		 		 * get info for dashboard aggregates line - for all entries (live + dead, as dead) 
		 		 * @returns promise
		 		 */
		 		DashboardSvc.getDeadAggregates = function getDeadAggregates() {
		 			var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveReportInputFilter',
			            'filter:fromTime': DashboardSvc.HOURS_AGO_IN_SEC,
			            'filter:toTime': '-2',
			            'filter:live': '0',
			            'pager:objectType': 'KalturaFilterPager',
			            'pager:pageIndex': '1',
			            'pager:pageSize': DashboardSvc.pageSize,
			            'reportType': 'PARTNER_TOTAL',
			            'service': 'livereports',
			            'action': 'getreport'
			        };
					
					return KApi.doRequest(postData);
		 		};
		 		
		 		/**
		 		 * get info for dashboard aggregates line - for currently live Kaltura-live entries 
		 		 * @returns promise
		 		 */
		 		DashboardSvc.getLiveAggregates = function getLiveAggregates() {
		 			/* MR:
		 			 * audience - 10 secs (now)
		 			 * minutes viewed - 36 hours
		 			 * buffertime - 1 minute
		 			 * bitrate - 1 minute
		 			 * */
		 			var postData = {
		 					'ignoreNull': '1',
		 					'service': 'multirequest',
		 					// 1 - audience - now
		 					'1:filter:objectType': 'KalturaLiveReportInputFilter',
		 					'1:filter:fromTime': '-60',
		 					'1:filter:toTime': '-60',
		 					'1:filter:live': '1',
		 					'1:pager:objectType': 'KalturaFilterPager',
		 					'1:pager:pageIndex': '1',
		 					'1:pager:pageSize': DashboardSvc.pageSize,
		 					'1:reportType': 'PARTNER_TOTAL',
		 					'1:service': 'livereports',
		 					'1:action': 'getreport',
	 						// 2 - minutes viewed - 36 hours
	 						'2:filter:objectType': 'KalturaLiveReportInputFilter',
	 						'2:filter:fromTime': DashboardSvc.HOURS_AGO_IN_SEC,
	 						'2:filter:toTime': '-2',
	 						'2:filter:live': '1',
	 						'2:pager:objectType': 'KalturaFilterPager',
	 						'2:pager:pageIndex': '1',
	 						'2:pager:pageSize': DashboardSvc.pageSize,
	 						'2:reportType': 'PARTNER_TOTAL',
	 						'2:service': 'livereports',
	 						'2:action': 'getreport',
 							// 3 - buffertime, bitrate - 1 minute
 							'3:filter:objectType': 'KalturaLiveReportInputFilter',
 							'3:filter:fromTime': '-60',
 							'3:filter:toTime': '-2',
 							'3:filter:live': '1',
 							'3:pager:objectType': 'KalturaFilterPager',
 							'3:pager:pageIndex': '1',
 							'3:pager:pageSize': DashboardSvc.pageSize,
 							'3:reportType': 'PARTNER_TOTAL',
 							'3:service': 'livereports',
 							'3:action': 'getreport'
		 			};
		 			
		 			return KApi.doRequest(postData);
		 		};
		 		
		 		
		 		/**
		 		 * @private
		 		 * for all live entries - get stats
		 		 */
		 		DashboardSvc._getAllEntriesStats = function _getAllEntriesStats(pageNumber) {
					var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveReportInputFilter',
			            'filter:orderBy': '%2Bname',
			            'filter:fromTime': DashboardSvc.HOURS_AGO_IN_SEC,
			            'filter:toTime': '-2',
			            'pager:objectType': 'KalturaFilterPager',
			            'pager:pageIndex': pageNumber,
			            'pager:pageSize': DashboardSvc.pageSize,
			            'reportType': 'ENTRY_TOTAL',
			            'service': 'livereports',
			            'action': 'getreport'
			        };
					
					return KApi.doRequest(postData);
		 		};
		 		
		 		/**
		 		 * @private
		 		 * for all live entries - get entry objects (by ids)
		 		 */
		 		DashboardSvc._getAllEntriesEntries = function _getAllEntriesEntries(entryIds) {
		 			var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveStreamEntryFilter',
						'filter:idIn': entryIds,
			            'filter:orderBy': '-createdAt',
			            'service': 'livestream',
			            'action': 'list'
			        };
					return KApi.doRequest(postData);
		 		};
		 		
		 		/**
				 * get the list of entries to show
				 * @param pageNumber
				 */
		 		DashboardSvc.getAllEntries = function getAllEntries(pageNumber) {
		 			// get page from reports API, then use entry ids to get entry names from API
		 			
		 			// Creating a deferred object
		            var deferred = $q.defer();
		            
		            DashboardSvc._getAllEntriesStats(pageNumber).then(function (entryStats) {
						// entryStats is KalturaLiveStatsListResponse
						var ids = '';
						if (entryStats.totalCount > 0) {
							entryStats.objects.forEach(function(entry) {
								ids += entry.entryId + ","; 
							}); 
							DashboardSvc._getAllEntriesEntries(ids).then(function(entries) {
								// entries is LiveStreamListResponse
								entryStats.objects.forEach(function (entryStat) {
									// add entry name to stats object
									entries.objects.every(function (entry) {
										if (entryStat.entryId == entry.id) {
											entryStat.name = entry.name;
											entryStat.thumbnailUrl = entry.thumbnailUrl;
											entryStat.firstBroadcast = entry.firstBroadcast; // API returns secs
											entryStat.lastBroadcast = entry.lastBroadcast; // API returns secs
											entryStat.dvrStatus = entry.dvrStatus;
											return false;
										}
										return true;
									});
								});
								deferred.resolve(entryStats);
							});
						}
						else {
							// no entries returned stats, resolve.
							deferred.resolve(entryStats);
						}
					});
			 		
			 		// Returning the promise object
		            return deferred.promise;
				};
				
				
				/**
				 * @private
				 * @param pageNumber
				 */
				DashboardSvc._getLiveEntriesEntries = function _getLiveEntriesEntries(pageNumber) {
					var postData = {
				            'filter:orderBy': '%2Bname',
				            'filter:objectType': 'KalturaLiveStreamEntryFilter',
				            'filter:isLive': '1',
				            'ignoreNull': '1',
				            'pager:objectType': 'KalturaFilterPager',
				            'pager:pageIndex': pageNumber,
				            'pager:pageSize': DashboardSvc.pageSize,
				            'service': 'livestream',
				            'action': 'list'
				        };
					
					return KApi.doRequest(postData);
				};
				
				/**
				 * @private
				 * @param entryIds
				 */
				DashboardSvc._getLiveEntriesStats = function _getLiveEntriesStats(entryIds) {
					var postData = {
						'ignoreNull': '1',
						'service': 'multirequest',
						// 1 - minutes viewed - 36 hours - will have most results (entries)
			            '1:filter:objectType': 'KalturaLiveReportInputFilter',
			            '1:filter:orderBy': '-eventTime',
			            '1:filter:entryIds': entryIds,
			            '1:filter:live': 1,
			            '1:filter:fromTime': DashboardSvc.HOURS_AGO_IN_SEC,
			            '1:filter:toTime': '-2',
			            '1:reportType': 'ENTRY_TOTAL',
			            '1:service': 'livereports',
			            '1:action': 'getreport',
						// 2 - audience - now
						'2:filter:objectType': 'KalturaLiveReportInputFilter',
			            '2:filter:orderBy': '-eventTime',
			            '2:filter:entryIds': entryIds,
			            '2:filter:live': 1,
			            '2:filter:fromTime': '-60',
			            '2:filter:toTime': '-60',
			            '2:reportType': 'ENTRY_TOTAL',
			            '2:service': 'livereports',
			            '2:action': 'getreport',
			            // 3 - buffertime, bitrate - 1 minute
			            '3:filter:objectType': 'KalturaLiveReportInputFilter',
			            '3:filter:orderBy': '-eventTime',
			            '3:filter:entryIds': entryIds,
			            '3:filter:live': 1,
			            '3:filter:fromTime': '-60',
			            '3:filter:toTime': '-2',
			            '3:reportType': 'ENTRY_TOTAL',
			            '3:service': 'livereports',
			            '3:action': 'getreport'
			        };
					
					return KApi.doRequest(postData);
				};
				
				/**
				 * of the given list, get the entries that are currently live
				 */
				DashboardSvc.getLiveEntries = function getLiveEntries(pageNumber) {
					// liveEntry.list by isLive to know which ones are currently live, then use entry ids in reports API
					
					// Creating a deferred object
		            var deferred = $q.defer();
		            
		            DashboardSvc._getLiveEntriesEntries(pageNumber).then(function (entries) {
						// entries is LiveStreamListResponse 
						var ids = '';
						if (entries.totalCount > 0) {
							entries.objects.forEach(function(entry) {
								ids += entry.id + ","; 
							}); 
							ids = ids.substr(0, ids.length - 1);
							DashboardSvc._getLiveEntriesStats(ids).then(function(entryStatsMR) {
								// entryStatsMR is MR with KalturaLiveStatsListResponse
								var hours = entryStatsMR[0].objects;
								var now = entryStatsMR[1].objects; 
								var minute = entryStatsMR[2].objects;
								// -------------------------------------------------------------------------------
								// entry info (name, thumbnailUrl, firstBroadcast*1000)
								entries.objects.forEach(function (entry) {
									// add params with default value
									entry.audience = "0";
									entry.dvrAudience = "0";
									entry.bufferTime = "0";
									entry.avgBitrate = "0";
									entry.peakAudience = "0";
									entry.peakDvrAudience = "0";
									entry.secondsViewed = "0";
									entry.entryId = entry.id; // for consistency with dead entries variables
									// seconds viewed, peak audience - hours
									if (hours) {
										hours.every(function (entryStat) {
											if (entry.id == entryStat.entryId) {
												entry.secondsViewed = entryStat.secondsViewed;
												entry.peakAudience = entryStat.peakAudience;
												entry.peakDvrAudience = entryStat.peakDvrAudience;
												return false;
											}
											return true;
										});
									}
									// audience - now (1 minute ago)
									if (now) {
										now.every(function (entryStat) {
											if (entry.id == entryStat.entryId) {
												entry.audience = parseInt(entryStat.audience) + parseInt(entryStat.dvrAudience);
												return false;
											}
											return true;
										});
									}
									// buffertime, bitrate - 1 minute
									if (minute) {
										minute.every(function (entryStat) {
											if (entry.id == entryStat.entryId) {
												entry.bufferTime = entryStat.bufferTime;
												entry.avgBitrate = entryStat.avgBitrate;
												return false;
											}
											return true;
										});
									}
								});
								
								deferred.resolve(entries);
							});
						}
						else {
							// no currently live entries, resolve with empty data
							deferred.resolve({
		                        "objectType" : "LiveStreamListResponse",
		                        "objects" : null,
		                        "totalCount" : '0'
		                    });
						}
					});
			 		
			 		// Returning the promise object
		            return deferred.promise;
				};
		 		
				
				/**
		 		 * trigger dashboard export to csv
		 		 */
		 		DashboardSvc.export2csv = function export2csv(liveOnly) {
		 			var d = new Date();
		 			
		 			var postData = {
						'ignoreNull': '1',
			            'service': 'livereports',
			            'action': 'exporttocsv',
			            'params:objectType': 'KalturaLiveReportExportParams',
			            'params:timeZoneOffset': d.getTimezoneOffset(),
						'params:applicationUrlTemplate': KApi.getExportHandlerUrl(),
			            'reportType': liveOnly ? '2' : '1' // KalturaLiveReportExportType.PARTNER_TOTAL_LIVE/PARTNER_TOTAL_ALL
			        };
					return KApi.doRequest(postData);
		 		};
		 		
		 		return DashboardSvc;
		 	} 
	 	]);


analyticsServices.factory('EntrySvc',
		['KApi', '$resource', '$q', 
		 	function EntrySvcFactory(KApi, $resource, $q) {
		 		var EntrySvc = {};

				EntrySvc.HOURS_AGO_IN_SEC = -129600;
		 		
		 		/**
		 		 * get the entry, add isLive info
		 		 * @param entryId
		 		 */
		 		EntrySvc.getEntry = function getEntry(entryId) {
		 			var dfd = $q.defer();
		 			var postData = {
		 					'service': 'multirequest',
		 					'1:service': 'liveStream',
				            '1:entryId' : entryId,
				            '1:action': 'get',
				            '2:service': 'liveStream',
				            '2:action': 'islive',
				            '2:id': entryId,
				            '2:protocol': 'hds',
							'3:service': 'liveStream',
				            '3:action': 'islive',
				            '3:id': entryId,
				            '3:protocol': 'hls',
							'4:service': 'liveStream',
				            '4:action': 'islive',
				            '4:id': entryId,
				            '4:protocol': 'hdnetworkmanifest'
				        };
					
		 			KApi.doRequest(postData).then(function (mr) {
						// the last 3 results are all current optional protocols.
						if (mr[0].objectType != "KalturaAPIException") {
							if (mr[0].sourceType == 31) {
								// Kaltura_Client_Enum_SourceType.AKAMAI_UNIVERSAL_LIVE
								var livehdnetwork = true;
								if (!mr[3] || mr[3].objectType == "KalturaAPIException") {
									livehdnetwork = false;
								}
								mr[0].isLive = livehdnetwork;
							}
							else if (mr[0].sourceType == 32) {
								// Kaltura_Client_Enum_SourceType.LIVE_STREAM
								var livehds = true;
								if (!mr[1] || mr[1].objectType == "KalturaAPIException") {
									livehds = false;
								}
								var livehls = true;
								if (!mr[2] || mr[2].objectType == "KalturaAPIException") {
									livehls = false;
								}
								mr[0].isLive = livehds || livehls;
							}
							else {
								mr[0].isLive = false;
							}
						}

		 				dfd.resolve(mr[0]);
		 			});
		 			
					return dfd.promise;
		 		};
		 		
		 		
		 		/**
		 		 * get aggregated stats data for this entry as a dead-now entry
		 		 * @param entryId
		 		 * @returns KalturaEntryLiveStats 
		 		 */
		 		EntrySvc.getDeadAggregates = function getDeadAggregates(entryId) {
		 			var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveReportInputFilter',
						'filter:fromTime': EntrySvc.HOURS_AGO_IN_SEC,
			            'filter:toTime': '-2',
			            'filter:entryIds': entryId,
			            'filter:live': '0',
			            'reportType': 'ENTRY_TOTAL',
			            'service': 'livereports',
			            'action': 'getreport'
			        };
		 			
					return KApi.doRequest(postData);
		 		};
		 		
		 		
		 		/**
		 		 * get aggregated stats data for this entry as a live-now entry
		 		 * @param entryId
		 		 * @returns KalturaEntryLiveStats 
		 		 */
		 		EntrySvc.getLiveAggregates = function getLiveAggregates(entryId) {
		 			/* MR:
		 			 * audience - 10 secs (now)
		 			 * minutes viewed - 36 hours
		 			 * buffertime - 1 minute
		 			 * bitrate - 1 minute
		 			 * */
		 			var postData = {
		 					'ignoreNull': '1',
		 					'service': 'multirequest',
		 					// 1 - audience - now
		 					'1:filter:objectType': 'KalturaLiveReportInputFilter',
		 					'1:filter:fromTime': '-60',
		 					'1:filter:toTime': '-60',
		 					'1:filter:live': '1',
		 					'1:filter:entryIds': entryId,
		 					'1:reportType': 'ENTRY_TOTAL',
		 					'1:service': 'livereports',
		 					'1:action': 'getreport',
	 						// 2 - minutes viewed - 36 hours
	 						'2:filter:objectType': 'KalturaLiveReportInputFilter',
	 						'2:filter:fromTime': EntrySvc.HOURS_AGO_IN_SEC,
	 						'2:filter:toTime': '-2',
	 						'2:filter:live': '1',
	 						'2:filter:entryIds': entryId,
	 						'2:reportType': 'ENTRY_TOTAL',
	 						'2:service': 'livereports',
	 						'2:action': 'getreport',
 							// 3 - buffertime, bitrate - 1 minute
 							'3:filter:objectType': 'KalturaLiveReportInputFilter',
 							'3:filter:fromTime': '-60',
 							'3:filter:toTime': '-2',
 							'3:filter:live': '1',
 							'3:filter:entryIds': entryId,
 							'3:reportType': 'ENTRY_TOTAL',
 							'3:service': 'livereports',
 							'3:action': 'getreport'
		 			};
		 			
		 			return KApi.doRequest(postData);
		 		};
		 		
		 		
		 		/**
		 		 * 
		 		 * @param entryId
		 		 * @returns
		 		 */
		 		EntrySvc.getReferrers = function getReferrers(entryId) {
		 			var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveReportInputFilter',
						'filter:fromTime': EntrySvc.HOURS_AGO_IN_SEC,
			            'filter:toTime': '-2',
			            'filter:entryIds': entryId,
			            'pager:objectType': 'KalturaFilterPager',
			            'pager:pageIndex': '1',
			            'pager:pageSize': '10',
			            'reportType': 'ENTRY_SYNDICATION_TOTAL',
			            'service': 'livereports',
			            'action': 'getreport'
			        };
					
					return KApi.doRequest(postData);
		 		};
		 		
		 		
		 		
		 		/**
		 		 * get graph data for base 36 hours
		 		 * @param entryId
		 		 * @param fromDate (timestamp sec)
		 		 * @param toDate (timestamp sec)
		 		 * @returns
		 		 */
		 		EntrySvc.getGraph = function getGraph(entryId, fromDate, toDate) {
		 			var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveReportInputFilter',
						'filter:fromTime': fromDate,
			            'filter:toTime': toDate,
			            'filter:entryIds': entryId,
			            'reportType': 'ENTRY_TIME_LINE',
			            'service': 'livereports',
			            'action': 'getevents'
			        };
					
					return KApi.doRequest(postData);
		 		};
		 		
		 		
		 		
		 		/**
		 		 * get map data for required time
		 		 * @param entryId
		 		 * @param time	(timestamp sec)
		 		 * @returns
		 		 */
		 		EntrySvc.getMap = function getMap(entryId, time) {
		 			var postData = {
						'ignoreNull': '1',
						'filter:objectType': 'KalturaLiveReportInputFilter',
						'filter:fromTime': time,
			            'filter:toTime': time,
			            'filter:entryIds': entryId,
						'filter:orderBy' : '-audience', //KalturaLiveReportOrderBy.AUDIENCE_DESC
						'pager:objectType': 'KalturaFilterPager',
						'pager:pageIndex': '1',
						'pager:pageSize': '1000',
			            'reportType': 'ENTRY_GEO_TIME_LINE',
			            'service': 'livereports',
			            'action': 'getreport'
			        };
					
					return KApi.doRequest(postData);
		 		};
		 		
		 		
		 		/**
		 		 * trigger entry export to csv
		 		 * @param reportType as enumerated in KalturaLiveReportExportType
		 		 * @param entryId 
		 		 */
		 		EntrySvc.export2csv = function export2csv(reportType, entryId) {
		 			var d = new Date();
		 			var postData = {
						'ignoreNull': '1',
			            'service': 'livereports',
			            'action': 'exporttocsv',
			            'params:objectType': 'KalturaLiveReportExportParams',
			            'params:timeZoneOffset': d.getTimezoneOffset(),
			            'params:entryIds': entryId,
						'params:applicationUrlTemplate': KApi.getExportHandlerUrl(),
						'reportType': reportType

			        };
					return KApi.doRequest(postData);
		 		};




				/**
				 *
				 * @param entryId
				 */
		 		EntrySvc.listEventCuepoints = function listEventCuepoints(entryId) {
					var postData = {
						'ignoreNull': '1',
						'service': 'cuepoint_cuepoint',
						'action': 'list',
						'filter:objectType': 'KalturaEventCuePointFilter',
						'filter:entryIdEqual': entryId,
						'filter:orderBy': '%2BstartTime'
					};
					return KApi.doRequest(postData);
				}

				return EntrySvc;
		 	} 
	 	]);

analyticsServices.factory('ReportSvc',
	['KApi', 'SessionInfo',
		function ReportSvcFactory(KApi, SessionInfo) {
			var ReportSvc = {};


			/**
			 *
			 * @param ks
			 * @returns
			 */
			ReportSvc.getSession = function getSession(ks) {
				SessionInfo.setKs(ks);
				var postData = {
					'ignoreNull': '1',
					'service': 'session',
					'action': 'get'
				};

				return KApi.doRequest(postData);
			};


			return ReportSvc;
		}
	]);





var en_US_trans = {
	// aggregates - keys should match Kaltura server 
	"audience": "Audience",
	"audience_inc_dvr" : "Audience & DVR",
	"plays" : "Plays",
	"seconds_viewed": "Minutes Viewed", // text should read minutes, not seconds
	"buffertime": "Average Buffering Time per Minute (seconds)",
	"bitrate": "Average Bitrate (kbps)",
	"agg_audience_tt": "Number of viewers at the moment",
	"agg_plays_tt": "Number of plays by viewers",
	"agg_secs_tt":"Sum of minutes viewed by all viewers so far",
	"agg_buffer_tt":"Average time per minute that viewers experienced buffering",
	"agg_bitrate_tt":"The average bitrate viewers are consuming",
	"export_to_csv": "Export To CSV",

	
	
	"dashboard" : {
		"Live_Content_36": "Live Content (in past 36 hours)",
		"Show_All_Entries": "All Viewed Live Entries",
		"Show_Kaltura": "Kaltura Live Now Only",
		"Audience": "Audience",
		"audience_inc_dvr" : "Audience & DVR",
		"Plays": "Plays",
		"Peak_Audience": "Peak Audience",
		"Peak_DVR_Audience": "Peak DVR",
		"Minutes_Viewed": "Minutes Viewed",
		"Buffer_Time": "Buffering Time",
		"Avg_Bitrate": "Average Bitrate",
		"Investigate": "Details",
		"first_broadcast": "First broadcast",
		"first_broadcast_tt": "First broadcast start time",
		"last_broadcast": "Last broadcast",
		"last_broadcast_tt": "Last broadcast start time",
		"export_success": "Your download request is being processed. A download link will be sent to {0} once processing is completed.",
		"export_fail": "Oooops, this didn\'t play out well. Please try again later."
	},
	
	"entry" : {
		"ID": "Entry ID",
		"Live_Content": "Live Content",
		"Audience": "Audience",
		"Location": "Location",
		"Location_tt": "Audience change based on geography and time",
		"Top_referals": "Top Referrers",
		"Top_referals_tt": "Top HTTP referrers that most viewers visited to view the live media",
		"Domain": "Referrer",
		"Visits": "Visits",
		"of_total": "% of total",
		"export_success": "Your download request is being processed. A download link will be sent to {0} once processing is completed.",
		"export_fail": "Oooops, this didn\'t play out well. Please try again later.",
		"report_timeline": "Audience",
		"report_location": "Location",
		"report_syndication": "Referrers"
	},
	
	"main" : {
		// tab names (translations) should match names in KMC analytics
		"Content_Reports": "Content Reports",
		"Community_Reports": "Users & Community Reports",
		"Storage_Reports": "Bandwidth & Storage Reports",
		"System_Reports": "System Reports",
		"Live_Reports": "Live Reports",
		"Real_Time_Reports": "Live Real-Time Dashboard",
		"n_a" : "N/A"
	},

	"export" : {
		"Header" : "Report Download",
		"Verifying" : "Verifying your download..",
		"Report_Ready" : "The report is ready for download.",
		"Download" : "Click here to download your Report..",
		"Expired" : "Download link has expired."
	}

};
