
$(document).ready(function() {
    
    var $btn = $("#Kbtn-navbar"),
        $menu = $("#sidr"),
        $categoryView = $("#categoryview"),
        $galleryGrid = $('#galleryGrid'),
        $galleryGridGrid = $('#galleryGrid.grid'),
        $entryCarousel = $('#entryCarousel'),
        $categoryCarousel = $(".category-carousel"),
        $categorySearchBar = $('.category-search-bar'),
        $categorySearchTab = $(".category-search-tab"),
        $header = $('#header'),
        $captions = $('#Captions'),
        $entryButtons = $('#entryButtons'),
        $channelModerationTable = $('#channelModerationTable'),
        $categoryModerationTable = $('#categoryModerationTable'),
        $mainChannelContent = $('#mainChannelContent'),
        $successLabel = $('#mediaStatusBadge.label-success');


    if ( ! Modernizr.touch) {
        $btn.addClass("--hover");
    }
    $menu.on("sidr:closing", function() {
        requestAnimationFrame(function() {
            $btn.removeClass("active");
        }, 0);
    });


    // add-new tooltip
    $('#categoryCarousel').find('.btn').kmsTooltip({placement: 'bottom'});

    // category type switch
    $categoryView.on('click', '.shortView', function() {
        $('.accordion-body').css('height','');
        $('.accordion-inner').css('display','');
    });
    $categoryView.on('click', '.gridView', function() {
        $('.accordion-body').css('height','');
        $('.accordion-inner').css('display','');
    });
    $categoryView.on('click', '.longView', function() {
        $('.accordion-body').css({'height':'auto'});
        $('.accordion-inner').css({'display':''});
        $('.description').css({'transform':''});
        $('.buttons').css({'transform':''});
        $('span.set-thumb').css({'bottom':''}); 
        $('.thumb_time').css({'display':''});       
    });

    // category accordion show
    $galleryGrid.on('show', '.accordion',function(e){
        // '.collapse' id's the short view
        if ($(e.target).hasClass('collapse')) {
            var parentLI = $(this).parents('li.galleryItem');
            setTimeout(function(){
                parentLI.css('height','160px');
                $('.description', parentLI).css({'transform':'translateY(40px)'});
                $('.buttons', parentLI).css({'transform':'translateY(40px)'});
                $('span.set-thumb', parentLI).css({'bottom':'112px'});  
                $('.thumb_time', parentLI).css({'display':'block'});    
                $('ul#gallery').kmsIsotope('reLayout');
            }, 100);
        }
    });    

    // category accordion hide
    $galleryGrid.on('hidden', '.accordion', function(e){
        // '.collapse' id's the short view      
        if ($(e.target).hasClass('collapse')) {
            var parentLI = $(this).parents('li.galleryItem');
            setTimeout(function(){
                $('.accordion-body', this).css({'height':'auto'});
                $('.accordion-inner', this).css({'display':''});
                $('.description', parentLI).css({"transform": ""});
                $('.buttons', parentLI).css({"transform": ""});
                $('span.set-thumb', parentLI).css({'bottom':''});
                $('.thumb_time', parentLI).css({'display':''});                                 
            }.bind(this), 100);
        }
    });    


    // entry categories
    $entryCarousel.on('click', '.expandable dl dd > a',function(e){
        if ($entryCarousel.find('.carousel-inner').css('overflow') == 'hidden') {
            $entryCarousel.find('.carousel-inner').css('overflow', 'visible');

            // setup the entry categories popover
            $entryCarousel.find('.expandable #appearsIn + dd').popover({
                'placement' : 'bottom',
                'html': true,
                'content' : $entryCarousel.find('.expandable #appearsIn + dd').html()
            });

            $entryCarousel.find('.expandable #appearsIn + dd').popover('show');

            $('body').one('click', function(){
                $entryCarousel.find('.carousel-inner').css('overflow', 'hidden');
                $entryCarousel.find('.expandable #appearsIn + dd').popover('hide');
            });
        }

        e.stopPropagation();
        e.preventDefault();
        return false;
    });

    // entry metadata tooltip
    $entryCarousel.find('.expandable dl dt.customdata+dd>div').each(function(){
        $( this ).attr('title', $( this ).html());
    });
    $entryCarousel.find('.expandable dl dt.customdata+dd>div').kmsTooltip({placement: 'top'});

    // channel/category search
    $categorySearchTab.on('click', function(event){
        var $nav = $categoryCarousel.find('.category-tabs__nav'),
            $dropdown = $categoryCarousel.find('.js-dropdown-container');
        $categorySearchBar.css({'transition-delay': '0.4s'});
        $categorySearchBar.css({'visibility': 'visible'});
        // adds the clear icon
        $categorySearchBar.find("i").show();
        $categorySearchBar.find('.navbar-search-wrapper .clear-icon').removeClass('hidden');
        [$nav, $dropdown].forEach(function($item) {
            $item.css({
                'transform':"translateX(-100%)",
                "opacity": 0
            });
        });
        // otherwise the focus will be lost
        setTimeout(function(){
            $categorySearchBar.show();
            $dropdown.css('visibility', 'hidden');
            $categorySearchBar.find('.navbar-search-wrapper input').focus();
        }, 300);

        event.stopPropagation();
        return false;
    });
    $categorySearchBar.find('.navbar-search-wrapper .clear-icon').on('click',function(event){
        var $nav = $categoryCarousel.find('.category-tabs__nav'),
            $dropdown = $categoryCarousel.find('.js-dropdown-container');
        $nav.get(0).style.display = "";
        $categorySearchBar.css({'transition-delay': '0s'});
        requestAnimationFrame(function() {
            [$dropdown, $nav].forEach(function($item) {
                $item.css({
                    'transform' : '',
                    'opacity': 1
                });
            });
            $dropdown.css('visibility', 'visible');
            $categorySearchBar.css('visibility', 'hidden');
            $categorySearchBar.css('display', 'block');
            $categorySearchBar.find('i').show();
        });
    });

    // add content tab
    $('.tab-addcontent').on('click', function(){
        $('.category-tabs__wrapper')
            .addClass('moved')
            .css({
                'transform' : "translateX(-100%)",
                "opacity"   : 0
            });
        // reset the search form, just in case

        $categorySearchBar.css({'visibility': 'hidden'});
        $categorySearchTab.find('i').show();
    });
    // id the end of the add media(media added, or cancel), and bring the tabs back
    $categoryCarousel.on('slide', function(){
        $('.category-tabs__wrapper').filter(".moved")
            .removeClass('moved')
            .css({
                'transform' : '',
                'opacity'   : '1'
            });
    });

    // global search
    $('#gsearchv2, #gsearchv2m').on('click', function(event){
        $header.find('#search').css('cssText','display: block !important');
        $header.find('#search .navbar-search-wrapper')
            .addClass('modal fade')
            .modal();
        $header.find('#search .navbar-search-wrapper input').focus();
    });

    // gallery grid entry thumbnail buttons
    $galleryGridGrid.on('click', '.thumbnail .accordion-body .buttons-expand',function(event){
        var easeInElement = function(element){
            $(element).show();
            $(element).animate({"height": '40px'}, 100,function(){easeInElement($(this).next())});
        }

        var stats = $(event.target).parent().siblings('.stat_data');
        if ( stats.is(':visible') ){
            stats.fadeOut(200,function(){
                // the buttons elements
                var buttons_wrapper = $(event.target).parent().siblings('.buttons');
                var buttons = buttons_wrapper.children();

                // hide all the individulal buttons
                buttons.hide();
                buttons.css('height', '0px');
                
                // show the individual buttons one by one
                buttons_wrapper.show();
                easeInElement(buttons_wrapper.children(':first-child'));
            });
        }

        // add the tooltip. adding here solves delegation, and attachment to an internal element
        // (to avoid mouseout event when hover on the tooltip)
        var accordion = $(event.target).parents('.galleryItemDetails');
        $(accordion).find('a').tooltip('destroy').tooltip({'container': '#' + accordion.attr('id'), 'placement': 'top'});

    });
    $galleryGridGrid.on('mouseleave', '.galleryItem',function(event){
        if ($(event.delegateTarget).hasClass('grid')) {
            // reset the buttons/stat visibility
            $(event.currentTarget).find('.stat_data').show();
            $(event.currentTarget).find('.buttons').hide();
        }
    });


    // captions search
    $entryButtons.one('click', '#tab-Captions',function(event){
        // if the page was loaded with the captions searh active
        $('.videoSearchInput').click();
    });


    $entryButtons.on('click', '.videoSearchInput',function(event){
        var $captionSearch = $('#captionSearch');

        if (event.target === this) {
            var $dropDownButtons = $(".js-dropdown-container");

            $entryButtons.css('position','relative');
            $entryButtons.find('> ul:not(#langCombo) > li:not(#Captions)').css('visibility', 'hidden');
            $dropDownButtons.animate({"opacity": 0});

            $('#Captions').css('right','auto');
            var position = this.parentElement.offsetLeft;
            $entryButtons.animate({'left' : -position}, function(){
                $('.videoSearchInput').addClass('open');
                $('.videoSearchInput input').focus();
                $('#Captions').css('left',position);
            });
        }

        // remove the data-to from the languages - the carousel is always in 
        // the right tab
        $('#langCombo').find('a[href=#entryCarousel]').attr('data-to', '');

        // prevent the tab from activating on focus - before a query is entered
        $captionSearch.off('focus');

        // reattach the click event on query enter
        var searchTimeout_v2;
        $captionSearch.keyup(function(){
            clearTimeout(searchTimeout_v2);
            searchTimeout_v2=setTimeout(function(){
                $('#tab-Captions').click();
            }, 800);
        });
    });

    $entryButtons.on('click', '.videoSearchInput #clear-icon',function(event){
        $('.videoSearchInput').removeClass('open');
        $(".js-dropdown-container").animate({"opacity": 1});
        $entryButtons.animate({'left' : 0}, function(){
            $captions.css('right','');
            $captions.css('left','');
            $entryButtons.find('ul li:not(#Captions)').css('visibility', 'visible');
            $entryButtons.find('> ul:not(#langCombo) > li:not(#Captions):first-child > a').click();
        });
    });


    // pending buttons - toggle the main and single buttons
    $('#channelmoderation-pane').on('click', '#channelModerationTable :checkbox[databulkenabled=true]',function(){
        if ($channelModerationTable.find(':checkbox:checked[databulkenabled=true]').length == 0) {
            $channelModerationTable.find('.entryActions .btn').show();
        }else{
            $channelModerationTable.find('.entryActions .btn').hide();
        }
    });

    $('#categorymoderation-pane').on('click','#categoryModerationTable :checkbox[databulkenabled=true]',function(){
        if ($categoryModerationTable.find(':checkbox:checked[databulkenabled=true]').length == 0) {
            $categoryModerationTable.find('.entryActions .btn').show();
        }else{
            $categoryModerationTable.find('.entryActions .btn').hide();
        }
    });

    // channel playlist carousel hover
    $mainChannelContent.find('#channelPlaylists-pane').on('mouseenter mouseleave','.thumbnail', function(event){
        var body = $('body');
        if (!(body.hasClass('ie11') || body.hasClass('ie10') || body.hasClass('ie9'))) {
            // mark as active, but not on ie - they dont respond well to the effect
            $(event.target).parents('.thumbnails').toggleClass('active');
        }
    }); 
    // channel playlist carousel - overflow. we need overflow to show the controls, but dont want it during sliding
    $mainChannelContent.find('#channelPlaylists-pane').on('slide','.playlist-carousel-container .carousel', function(event){
        $(event.target).css('overflow', 'hidden');
    });
    $mainChannelContent.find('#channelPlaylists-pane').on('slid','.playlist-carousel-container .carousel', function(event){
        $(event.target).css('overflow', '');
    });


    // edit entry page - entry publish popover
    $successLabel.popover({
        'placement' : 'bottom',
        'html': true,
        'content' : $('#editEntryMedia').find('.detailsOfPublish').html()
    });
    $successLabel.hover(function(){
        $('#mediaStatusBadge').popover('toggle')
    });

    // my media page - entry publish popover
    $('#myMediaCarousel').on('click','.mymediaTable .accordion-toggle',function(event){     
        if( $(event.currentTarget).parents('.accordion-group').next().length ){
            // move the target to the pop up
            var content = $(event.currentTarget.hash).clone();
            $(event.currentTarget.hash).remove();

            $(event.target).popover({
                'placement' : 'bottom',
                'html' : true,
                'title' : '',
                'content' : content
            });

            $(event.target).popover('show');
        }
        else{
            // prevent the accordion from engaging
            event.stopPropagation();
            event.preventDefault();
        }
    });

});


// inline seach forms that are ajax driven
function KMSV2UI_inline_search_form_ajax(wrapper,keyword){
    KMSV2UI_inline_search_form($(wrapper));

    // if we have a keyword, show the form as open
    if (keyword) {
        var form = $(wrapper + ' .navbar-search');
        form.addClass('active');
        form.find('#searchBar').css('max-width', '400px');
        form.find('input').focus(); 
    }
};

// make a search form collapsible inline. works together with .inline-inplace-search-form-mixin
function KMSV2UI_inline_search_form(wrapper){
    wrapper.on('click', '.navbar-search-wrapper #search-icon',function(event){
        var form = $(event.target).parents('form');

        form.addClass('active');
        form.find('#searchBar').animate({'max-width': '400px'}, function(){
            form.find('input').focus(); 
        });
    });
    wrapper.on('click', '.navbar-search-wrapper .clear-icon',function(event){
        var form = $(event.target).parents('form');

        form.find('#searchBar').animate({'max-width': '0'}, function(){
            form.removeClass('active');
        });
    });
};

function KMSV2UI_addPlaylistButtons(playlistId) {
    var $embedPlaylistButton = $("#embedplaylist-" + playlistId + "-tab"),
        $deletePlaylistButton = $("#dlt_" + playlistId),
        $newButtonsWrapper = $("<div class='playlistActionsWrapper'>"),
        $newDeleteButton = $("<i class='v2ui-deleteButton-" + playlistId + " icon-trash'>"),
        $newEmbedButton = $embedPlaylistButton.length === 0 ? '' : $("<i class='v2ui-embedplaylistButton-" + playlistId + " icon-code'>");

    // copy events from old ui buttons
    if($newEmbedButton) {
        $newEmbedButton.on('click', function () {
            $embedPlaylistButton.click();
        });
    }

    $newDeleteButton.on('click', function() {
        $deletePlaylistButton.click();
    });

    $newButtonsWrapper.append($newEmbedButton, $newDeleteButton).appendTo($(".nav-list.bs-docs-sidenav li.active"));
}


function KMSV2UI_replaceChannelImage(thumbnailUrl, allowReset) {
    // update images
    var $poster = $('#channel-poster');
    $poster.find('img.blurred').attr('src', thumbnailUrl);
    $poster.find('img.focus').attr('src', thumbnailUrl);
    $("#thumbSvg").attr('xlink:href', thumbnailUrl);
    // make sure images are visible
    $(".channel-image").removeClass("hidden");
    $(".no-img-channel-header").addClass("hidden");

    // update the "reset thumb" button
    if (allowReset) {
        $('.category-actions #reset').removeClass('disabled');
    }
    else {
        $('.category-actions #reset').addClass('disabled');
    }
}